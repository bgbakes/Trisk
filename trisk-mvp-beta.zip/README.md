# TRISK Interactive MVP

A branded, mobile-responsive Next.js prototype for a private, consent-first lifestyle tracking platform for adults.

## Working in demo mode
- Public launch website
- Registration flow with 18+ and policy confirmations
- Member dashboard
- Scene and consent-plan builder
- Private wellness check-ins
- Connection and profile/privacy screens
- Safety Center and quick-exit control
- Founder claim page
- 90-day trial and first-50 promotion messaging
- Browser-local persistence for demo accounts, plans and check-ins

## Production foundation included
- Supabase browser client
- PostgreSQL migration with profiles, memberships, connections, scene plans, participants, private logs and safety reports
- Row Level Security starter policies
- Environment-variable template for Supabase and Stripe

## Run locally
1. Install Node.js 20 or later.
2. Run `npm install`.
3. Run `npm run dev`.
4. Open `http://localhost:3000`.

The demo works without Supabase credentials because temporary records are saved in browser localStorage. Connect Supabase before using real member data.

## Before accepting real users
- Replace localStorage with authenticated server-side database actions.
- Add verified email, MFA, session/device management and rate limiting.
- Implement atomic first-50 founder reservations.
- Connect Stripe Checkout, webhooks, the 90-day trial and a three-cycle 50% discount.
- Add immutable consent-version history and participant-specific signatures.
- Complete blocking, reporting, moderation and audit logs.
- Encrypt highly sensitive fields using an application-level key strategy.
- Add neutral notification previews and media protections.
- Obtain privacy, adult-platform, subscription, moderation and jurisdiction-specific legal review.
- Conduct security review and penetration testing.

A stored agreement must never be represented as overriding current withdrawal, refusal, incapacity or coercion concerns.
