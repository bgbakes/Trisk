import type {Metadata} from 'next';import './globals.css';
export const metadata:Metadata={title:{default:'TRISK — Track. Negotiate. Own.',template:'%s | TRISK'},description:'A private, consent-first lifestyle tracking and negotiation platform for adults.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
