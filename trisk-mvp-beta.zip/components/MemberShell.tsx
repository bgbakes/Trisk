'use client';
import Link from 'next/link';
import {usePathname} from 'next/navigation';
const links=[['/dashboard','Overview'],['/scene-builder','Scene Builder'],['/check-in','Wellness Check-In'],['/partners','Connections'],['/profile','Privacy & Profile'],['/safety','Safety Center']];
export default function MemberShell({children}:{children:React.ReactNode}){
 const path=usePathname();
 return <div className="dashboard"><aside className="sidebar"><Link className="brand" href="/"><b>◉</b> TRISK</Link><p className="muted small">Private member workspace</p><nav className="side-nav">{links.map(([href,label])=><Link key={href} className={path===href?'active':''} href={href}>{label}</Link>)}</nav><div className="side-bottom"><Link className="quick-exit" href="https://www.google.com">Quick exit</Link><p className="micro">Immediately leaves TRISK. Your browser history is not automatically cleared.</p></div></aside><main className="main">{children}</main></div>
}
