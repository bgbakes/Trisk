# Trisk — React Native App

**Power. Trust. Dynamic.**  
BDSM/kink community app — dynamic tracker + dating + community  
© 2025 Mestre'K Enterprises LLC · trisk.app

---

## Tech Stack

| Layer       | Technology                        |
|-------------|-----------------------------------|
| Framework   | React Native + Expo SDK 51        |
| Routing     | Expo Router (file-based)          |
| Backend     | Supabase (Postgres + Auth + RT)   |
| Styling     | StyleSheet (custom design system) |
| Billing     | Stripe                            |
| Deployment  | EAS Build (iOS + Android)         |

---

## Project Structure

```
trisk/
├── app/
│   ├── _layout.tsx           # Root layout (auth gate)
│   ├── (auth)/
│   │   ├── _layout.tsx       # Auth stack layout
│   │   ├── welcome.tsx       # Landing / splash screen
│   │   ├── login.tsx         # Sign in
│   │   ├── signup.tsx        # Sign up + role selection
│   │   └── onboarding.tsx    # 5-step profile setup
│   └── (tabs)/
│       ├── _layout.tsx       # Bottom tab nav
│       ├── connect.tsx       # Dating / discovery
│       ├── track.tsx         # Dynamic tracker
│       ├── scene.tsx         # Community feed
│       └── profile.tsx       # Profile + settings
├── components/
│   └── ui/
│       └── index.tsx         # Button, Card, Badge, Input, etc.
├── lib/
│   ├── supabase.ts           # Supabase client + helpers
│   ├── theme.ts              # Design tokens (colors, type, spacing)
│   └── types.ts              # Full TypeScript type definitions
├── supabase-schema.sql       # Run in Supabase SQL Editor
├── .env.example              # Copy to .env
├── app.json                  # Expo config
├── package.json
└── tsconfig.json
```

---

## Setup — Step by Step

### 1. Prerequisites

```bash
node --version    # 18+ required
npm --version     # 9+ required
```

Install Expo CLI globally:
```bash
npm install -g expo-cli eas-cli
```

### 2. Clone and install

```bash
cd trisk
npm install
```

### 3. Supabase setup

1. Go to [supabase.com](https://supabase.com) → New Project
2. Name: `trisk` · Region: `us-east-1` (closest to Las Vegas)
3. Copy your **Project URL** and **anon public key**
4. Open SQL Editor → paste contents of `supabase-schema.sql` → Run

### 4. Environment variables

```bash
cp .env.example .env
```

Edit `.env`:
```
EXPO_PUBLIC_SUPABASE_URL=https://YOUR_REF.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
```

### 5. Run the app

```bash
# iOS simulator (Mac only)
npm run ios

# Android emulator
npm run android

# Expo Go (physical device — fastest to test)
npm start
# Scan QR with Expo Go app
```

---

## App Features — Current Scaffold

### ✅ Built
- Auth flow: Welcome → Signup (with role) → Onboarding (5 steps) → Login
- Bottom tab navigation: Connect / Track / Scene / Profile
- Connect tab: Discover cards, matches list, messages (stub)
- Track tab: Overview, tasks with completion toggle, rules, journal stub, mood check-in
- Scene tab: Community feed with posts, upvotes, tags
- Profile tab: Profile display, privacy toggles, account settings, sign out
- Supabase client with secure storage, auth helpers, realtime subscriptions
- Full TypeScript types for all data models
- Complete design system (colors, typography, spacing, gradients, shadows)
- Database schema with RLS policies for all tables
- Reusable UI components: Button, Card, Badge, Input, EmptyState, ScreenHeader

### 🔨 Next to Build (v1 MVP)
- [ ] Real profile photos (expo-image-picker + Supabase Storage)
- [ ] Actual swipe gestures on discover cards (react-native-gesture-handler)
- [ ] Working messaging in Connect tab
- [ ] Task creation modal (Dom assigns to sub)
- [ ] Push notifications (Expo Notifications + Supabase triggers)
- [ ] Stripe subscription billing (Pro $9.99 + Elite $19.99)
- [ ] Dynamic contract PDF generator
- [ ] Journal rich text editor
- [ ] YES/NO/MAYBE kink checklist with partner sharing
- [ ] Lovense API integration (tasks trigger device events)

---

## Database Schema Overview

| Table           | Purpose                              |
|-----------------|--------------------------------------|
| profiles        | User profiles, roles, privacy        |
| dynamics        | D/s relationship structures          |
| tasks           | Assigned tasks + completion tracking |
| rules           | Dynamic rules/protocols              |
| rituals         | Daily/recurring rituals              |
| journal_entries | Private/shared journal               |
| check_ins       | Daily mood + submission check-ins    |
| matches         | Dating connections                   |
| messages        | Direct messages between matches      |
| posts           | Community feed posts                 |

All tables have Row Level Security (RLS) enabled.

---

## Subscription Tiers

| Feature                | Free | Pro ($9.99/mo) | Elite ($19.99/mo) |
|------------------------|------|-----------------|-------------------|
| Dynamic tracking       | 1    | Unlimited        | Unlimited          |
| Connect matches        | 10   | Unlimited        | Unlimited          |
| Journal entries        | 20   | Unlimited        | Unlimited          |
| Task assignment        | ✅   | ✅               | ✅                 |
| Lovense integration    | ❌   | ✅               | ✅                 |
| Multi-sub management   | ❌   | ❌               | ✅                 |
| Contract builder       | ❌   | ✅               | ✅                 |
| Analytics dashboard    | ❌   | ✅               | ✅                 |

---

## App Store Strategy

**Apple App Store:**
- Category: Lifestyle
- Age Rating: 17+
- App Store description uses "relationship dynamic tracker" language
- No explicit imagery in screenshots

**Google Play:**
- Category: Lifestyle
- Content Rating: Mature 17+
- Same positioning as Apple

**PWA fallback** at trisk.app for features Apple won't allow.

---

## Design System

Colors, typography, and spacing are defined in `lib/theme.ts`.

| Token           | Value      | Use                    |
|-----------------|------------|------------------------|
| `Colors.void`   | `#080806`  | Background             |
| `Colors.leather`| `#160e04`  | Cards, surfaces        |
| `Colors.gold`   | `#C49A2A`  | Primary gold           |
| `Colors.goldBright` | `#E8C244` | Active states, headers |
| `Colors.cream`  | `#F2EBD9`  | Primary text           |

Fonts: Cinzel (display) · Cormorant Garamond (editorial) · Outfit (UI)  
Load via `expo-google-fonts` in `app/_layout.tsx`.

---

## EAS Build (Production)

```bash
# Configure EAS
eas build:configure

# Build for iOS
eas build --platform ios --profile production

# Build for Android
eas build --platform android --profile production

# Submit to App Store
eas submit --platform ios

# Submit to Play Store
eas submit --platform android
```

---

## Keola's Setup Checklist

- [ ] `npm install` in `/trisk`
- [ ] Create Supabase project at supabase.com
- [ ] Run `supabase-schema.sql` in SQL Editor
- [ ] Copy `.env.example` → `.env` with Supabase keys
- [ ] `npm start` to launch Expo dev server
- [ ] Test on iOS Simulator or Expo Go
- [ ] Set up EAS account at expo.dev
- [ ] Configure Stripe webhooks for subscription events

---

**Trisk · trisk.app · © 2025 Mestre'K Enterprises LLC**  
*Built with ♥ in Las Vegas*
