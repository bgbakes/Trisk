// app/(auth)/_layout.tsx
import { Stack } from 'expo-router';
import { Colors } from '@/lib/theme';

export default function AuthLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: Colors.void },
        animation: 'fade',
      }}
    />
  );
}
