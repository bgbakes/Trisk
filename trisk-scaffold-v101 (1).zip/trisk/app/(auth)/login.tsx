// app/(auth)/login.tsx
import { useState } from 'react';
import {
  View, Text, TextInput, StyleSheet,
  Pressable, KeyboardAvoidingView, Platform, ScrollView, Alert
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { signIn } from '@/lib/supabase';
import { Colors, Typography, Spacing, Radius, Gradients } from '@/lib/theme';

export default function LoginScreen() {
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Missing fields', 'Enter your email and password.');
      return;
    }
    try {
      setLoading(true);
      await signIn(email.trim().toLowerCase(), password);
      // Auth state change triggers root layout redirect
    } catch (err: any) {
      Alert.alert('Login failed', err.message ?? 'Check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1, backgroundColor: Colors.void }}
    >
      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
      >
        <Pressable style={styles.back} onPress={() => router.back()}>
          <Text style={styles.backText}>← Back</Text>
        </Pressable>

        <Text style={styles.heading}>Welcome{'\n'}Back</Text>
        <Text style={styles.sub}>Your dynamic is waiting.</Text>

        <View style={styles.form}>
          <View style={styles.field}>
            <Text style={styles.label}>Email</Text>
            <TextInput
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              placeholder="your@email.com"
              placeholderTextColor={Colors.textDim}
              keyboardType="email-address"
              autoCapitalize="none"
              autoComplete="email"
            />
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>Password</Text>
            <TextInput
              style={styles.input}
              value={password}
              onChangeText={setPassword}
              placeholder="••••••••"
              placeholderTextColor={Colors.textDim}
              secureTextEntry
              autoComplete="current-password"
            />
          </View>

          <Pressable style={styles.forgot}>
            <Text style={styles.forgotText}>Forgot password?</Text>
          </Pressable>
        </View>

        <Pressable
          style={[styles.btn, loading && styles.btnDisabled]}
          onPress={handleLogin}
          disabled={loading}
        >
          <LinearGradient
            colors={Gradients.goldShort}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            style={styles.btnGradient}
          >
            <Text style={styles.btnText}>
              {loading ? 'Signing in...' : 'Enter'}
            </Text>
          </LinearGradient>
        </Pressable>

        <Pressable onPress={() => router.push('/(auth)/signup')}>
          <Text style={styles.switchText}>
            New to Trisk?{' '}
            <Text style={styles.switchLink}>Join the scene</Text>
          </Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: Colors.void,
    padding: Spacing['2xl'],
    justifyContent: 'center',
  },
  back: { marginBottom: Spacing['3xl'] },
  backText: {
    fontFamily: Typography.sans,
    fontSize: Typography.base,
    color: Colors.textMuted,
    letterSpacing: 1,
  },
  heading: {
    fontFamily: Typography.display,
    fontSize: Typography['3xl'],
    color: Colors.goldBright,
    letterSpacing: 2,
    marginBottom: Spacing.sm,
    lineHeight: Typography['3xl'] * 1.15,
  },
  sub: {
    fontFamily: Typography.serifItalic,
    fontSize: Typography.md,
    color: Colors.textMuted,
    marginBottom: Spacing['3xl'],
  },
  form: { gap: Spacing.base, marginBottom: Spacing.lg },
  field: { gap: Spacing.xs },
  label: {
    fontFamily: Typography.sans,
    fontSize: Typography.xs,
    letterSpacing: 2,
    textTransform: 'uppercase',
    color: Colors.textMuted,
  },
  input: {
    backgroundColor: Colors.leather,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.md,
    padding: Spacing.base,
    fontFamily: Typography.sans,
    fontSize: Typography.base,
    color: Colors.textPrimary,
  },
  forgot: { alignSelf: 'flex-end' },
  forgotText: {
    fontFamily: Typography.sans,
    fontSize: Typography.xs,
    color: Colors.goldDeep,
    letterSpacing: 1,
  },
  btn: { borderRadius: Radius.md, overflow: 'hidden', marginBottom: Spacing.xl },
  btnDisabled: { opacity: 0.6 },
  btnGradient: {
    paddingVertical: Spacing.base,
    alignItems: 'center',
    borderRadius: Radius.md,
  },
  btnText: {
    fontFamily: Typography.display,
    fontSize: Typography.base,
    letterSpacing: 3,
    color: Colors.void,
    textTransform: 'uppercase',
  },
  switchText: {
    fontFamily: Typography.sans,
    fontSize: Typography.sm,
    color: Colors.textMuted,
    textAlign: 'center',
  },
  switchLink: { color: Colors.goldBright },
});
