// app/(auth)/onboarding.tsx
// 5-step onboarding after signup

import { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  Pressable, TextInput, Alert
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { updateProfile, getUser } from '@/lib/supabase';
import { Colors, Typography, Spacing, Radius, Gradients } from '@/lib/theme';

const DYNAMIC_TYPES = ['D/s','M/s','O/p','DD/lg','MD/lb','CG/l','pet_play','TPE','other'];
const KINK_LIST = [
  'Bondage','Impact Play','Protocol','Service','Sensation Play',
  'Roleplay','Humiliation','Praise','Orgasm Control','Collar & Lead',
  'Aftercare Focus','Power Exchange','Age Play','Pet Play','Exhibitionism',
];

const STEPS = ['Role', 'Dynamic', 'Interests', 'Privacy', 'Ready'];

export default function OnboardingScreen() {
  const [step, setStep] = useState(0);
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [location, setLocation] = useState('');
  const [dynamicTypes, setDynamicTypes] = useState<string[]>([]);
  const [kinks, setKinks] = useState<string[]>([]);
  const [discreet, setDiscreet] = useState(false);
  const [loading, setLoading] = useState(false);

  const toggleItem = (arr: string[], setArr: Function, val: string) => {
    setArr((prev: string[]) =>
      prev.includes(val) ? prev.filter((x) => x !== val) : [...prev, val]
    );
  };

  const handleFinish = async () => {
    try {
      setLoading(true);
      const user = await getUser();
      if (!user) throw new Error('No user session');
      await updateProfile(user.id, {
        display_name: displayName,
        bio,
        location,
        dynamic_types: dynamicTypes,
        kinks,
        discreet_mode: discreet,
      });
      router.replace('/(tabs)/connect');
    } catch (err: any) {
      Alert.alert('Error', err.message);
    } finally {
      setLoading(false);
    }
  };

  const next = () => step < STEPS.length - 1 ? setStep(s => s + 1) : handleFinish();
  const back = () => step > 0 ? setStep(s => s - 1) : router.back();

  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient colors={['#160e04', Colors.void]} style={styles.header}>
        <Pressable onPress={back}>
          <Text style={styles.backText}>← {step === 0 ? 'Back' : 'Previous'}</Text>
        </Pressable>
        <View style={styles.stepRow}>
          {STEPS.map((_, i) => (
            <View key={i} style={[styles.stepDot, step >= i && styles.stepDotActive]} />
          ))}
        </View>
        <Text style={styles.stepLabel}>{step + 1} / {STEPS.length}</Text>
      </LinearGradient>

      <ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled">

        {/* ── STEP 0: Display name + bio ── */}
        {step === 0 && (
          <>
            <Text style={styles.stepTitle}>Build Your{'\n'}Scene Identity</Text>
            <Text style={styles.stepSub}>This is how the community knows you.</Text>

            <View style={styles.field}>
              <Text style={styles.label}>Display Name</Text>
              <TextInput
                style={styles.input}
                value={displayName}
                onChangeText={setDisplayName}
                placeholder="How you want to be known"
                placeholderTextColor={Colors.textDim}
              />
            </View>

            <View style={styles.field}>
              <Text style={styles.label}>Location (City only)</Text>
              <TextInput
                style={styles.input}
                value={location}
                onChangeText={setLocation}
                placeholder="Las Vegas, NV"
                placeholderTextColor={Colors.textDim}
              />
            </View>

            <View style={styles.field}>
              <Text style={styles.label}>Bio</Text>
              <TextInput
                style={[styles.input, styles.textarea]}
                value={bio}
                onChangeText={setBio}
                placeholder="Tell the scene who you are..."
                placeholderTextColor={Colors.textDim}
                multiline
                numberOfLines={4}
              />
            </View>
          </>
        )}

        {/* ── STEP 1: Dynamic types ── */}
        {step === 1 && (
          <>
            <Text style={styles.stepTitle}>Your{'\n'}Dynamic Style</Text>
            <Text style={styles.stepSub}>Select all that apply. You can always change this.</Text>
            <View style={styles.chipGrid}>
              {DYNAMIC_TYPES.map((dt) => (
                <Pressable
                  key={dt}
                  style={[styles.chip, dynamicTypes.includes(dt) && styles.chipActive]}
                  onPress={() => toggleItem(dynamicTypes, setDynamicTypes, dt)}
                >
                  <Text style={[styles.chipText, dynamicTypes.includes(dt) && styles.chipTextActive]}>
                    {dt}
                  </Text>
                </Pressable>
              ))}
            </View>
          </>
        )}

        {/* ── STEP 2: Kinks / interests ── */}
        {step === 2 && (
          <>
            <Text style={styles.stepTitle}>Your Interests</Text>
            <Text style={styles.stepSub}>Select what you're into. Shown to potential matches only.</Text>
            <View style={styles.chipGrid}>
              {KINK_LIST.map((k) => (
                <Pressable
                  key={k}
                  style={[styles.chip, kinks.includes(k) && styles.chipActive]}
                  onPress={() => toggleItem(kinks, setKinks, k)}
                >
                  <Text style={[styles.chipText, kinks.includes(k) && styles.chipTextActive]}>
                    {k}
                  </Text>
                </Pressable>
              ))}
            </View>
          </>
        )}

        {/* ── STEP 3: Privacy ── */}
        {step === 3 && (
          <>
            <Text style={styles.stepTitle}>Privacy{'\n'}First</Text>
            <Text style={styles.stepSub}>Trisk is built for discretion. You control everything.</Text>

            <Pressable
              style={[styles.privacyCard, discreet && styles.privacyCardActive]}
              onPress={() => setDiscreet(true)}
            >
              <View style={styles.privacyRow}>
                <View style={[styles.radio, discreet && styles.radioActive]} />
                <View style={styles.privacyInfo}>
                  <Text style={styles.privacyTitle}>Discreet Mode</Text>
                  <Text style={styles.privacyDesc}>
                    Only verified Trisk members can see your profile. Hidden from search engines.
                  </Text>
                </View>
              </View>
            </Pressable>

            <Pressable
              style={[styles.privacyCard, !discreet && styles.privacyCardActive]}
              onPress={() => setDiscreet(false)}
            >
              <View style={styles.privacyRow}>
                <View style={[styles.radio, !discreet && styles.radioActive]} />
                <View style={styles.privacyInfo}>
                  <Text style={styles.privacyTitle}>Standard</Text>
                  <Text style={styles.privacyDesc}>
                    Visible to all members. Easier to find matches and community.
                  </Text>
                </View>
              </View>
            </Pressable>

            <View style={styles.privacyNote}>
              <Text style={styles.privacyNoteText}>
                🔒 Your safewords, rules, and journal are always private — never shared with anyone except your dynamic partner, and only with your consent.
              </Text>
            </View>
          </>
        )}

        {/* ── STEP 4: Ready ── */}
        {step === 4 && (
          <View style={styles.readyWrap}>
            <Text style={styles.readySymbol}>⟁</Text>
            <Text style={styles.readyTitle}>You're Ready</Text>
            <Text style={styles.readySub}>
              Welcome to Trisk.{'\n'}Your scene. Your rules. Your dynamic.
            </Text>
            <View style={styles.readyStats}>
              {[
                { label: 'Discover', desc: 'Find your match' },
                { label: 'Track', desc: 'Manage your dynamic' },
                { label: 'Scene', desc: 'Community & events' },
              ].map((s) => (
                <View key={s.label} style={styles.readyStat}>
                  <Text style={styles.readyStatLabel}>{s.label}</Text>
                  <Text style={styles.readyStatDesc}>{s.desc}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

      </ScrollView>

      {/* CTA */}
      <View style={styles.footer}>
        <Pressable
          style={[styles.btn, loading && styles.btnDisabled]}
          onPress={next}
          disabled={loading}
        >
          <LinearGradient
            colors={Gradients.goldShort}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            style={styles.btnGrad}
          >
            <Text style={styles.btnText}>
              {loading ? 'Setting up...' : step === STEPS.length - 1 ? 'Enter the Scene' : 'Continue'}
            </Text>
          </LinearGradient>
        </Pressable>
        {step < STEPS.length - 1 && (
          <Pressable onPress={next}>
            <Text style={styles.skipText}>Skip for now</Text>
          </Pressable>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.void },
  header: { paddingTop: 56, paddingHorizontal: Spacing['2xl'], paddingBottom: Spacing.base, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  backText: { fontFamily: Typography.sans, fontSize: Typography.sm, color: Colors.textMuted, letterSpacing: 1, width: 80 },
  stepRow: { flexDirection: 'row', gap: Spacing.xs },
  stepDot: { width: 18, height: 3, borderRadius: 2, backgroundColor: Colors.textDim },
  stepDotActive: { backgroundColor: Colors.goldBright },
  stepLabel: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textDim, width: 80, textAlign: 'right' },
  body: { padding: Spacing['2xl'], paddingBottom: 160 },
  stepTitle: { fontFamily: Typography.display, fontSize: Typography['2xl'], color: Colors.goldBright, letterSpacing: 2, marginBottom: Spacing.sm, lineHeight: Typography['2xl'] * 1.2 },
  stepSub: { fontFamily: Typography.serifItalic, fontSize: Typography.base, color: Colors.textMuted, marginBottom: Spacing['2xl'], lineHeight: Typography.base * 1.6 },
  field: { gap: Spacing.xs, marginBottom: Spacing.base },
  label: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 2, textTransform: 'uppercase', color: Colors.textMuted },
  input: { backgroundColor: Colors.leather, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: Spacing.base, fontFamily: Typography.sans, fontSize: Typography.base, color: Colors.textPrimary },
  textarea: { height: 100, textAlignVertical: 'top' },
  chipGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  chip: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.leather },
  chipActive: { borderColor: Colors.goldBright, backgroundColor: 'rgba(196,154,42,0.15)' },
  chipText: { fontFamily: Typography.sans, fontSize: Typography.sm, color: Colors.textMuted, letterSpacing: 0.5 },
  chipTextActive: { color: Colors.goldBright },
  privacyCard: { borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.lg, padding: Spacing.base, marginBottom: Spacing.md, backgroundColor: Colors.leather },
  privacyCardActive: { borderColor: Colors.goldBright, backgroundColor: 'rgba(196,154,42,0.08)' },
  privacyRow: { flexDirection: 'row', gap: Spacing.md, alignItems: 'flex-start' },
  radio: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: Colors.border, marginTop: 2 },
  radioActive: { borderColor: Colors.goldBright, backgroundColor: Colors.goldBright },
  privacyInfo: { flex: 1 },
  privacyTitle: { fontFamily: Typography.display, fontSize: Typography.base, color: Colors.cream, letterSpacing: 1, marginBottom: 4 },
  privacyDesc: { fontFamily: Typography.sans, fontSize: Typography.sm, color: Colors.textMuted, lineHeight: Typography.sm * 1.5 },
  privacyNote: { marginTop: Spacing.base, padding: Spacing.base, borderRadius: Radius.md, backgroundColor: 'rgba(196,154,42,0.06)', borderWidth: 1, borderColor: Colors.border },
  privacyNoteText: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textMuted, lineHeight: Typography.xs * 1.6 },
  readyWrap: { alignItems: 'center', paddingTop: Spacing['3xl'] },
  readySymbol: { fontSize: 64, color: Colors.goldBright, marginBottom: Spacing.lg },
  readyTitle: { fontFamily: Typography.display, fontSize: Typography['3xl'], color: Colors.goldBright, letterSpacing: 4, marginBottom: Spacing.sm },
  readySub: { fontFamily: Typography.serifItalic, fontSize: Typography.md, color: Colors.textMuted, textAlign: 'center', lineHeight: Typography.md * 1.7, marginBottom: Spacing['3xl'] },
  readyStats: { flexDirection: 'row', gap: Spacing.xl },
  readyStat: { alignItems: 'center' },
  readyStatLabel: { fontFamily: Typography.display, fontSize: Typography.sm, color: Colors.goldBright, letterSpacing: 2 },
  readyStatDesc: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textMuted, letterSpacing: 0.5, marginTop: 4 },
  footer: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: Spacing['2xl'], paddingBottom: Spacing['3xl'], backgroundColor: Colors.void, borderTopWidth: 1, borderTopColor: Colors.border, gap: Spacing.sm },
  btn: { borderRadius: Radius.md, overflow: 'hidden' },
  btnDisabled: { opacity: 0.6 },
  btnGrad: { paddingVertical: Spacing.base, alignItems: 'center' },
  btnText: { fontFamily: Typography.display, fontSize: Typography.base, letterSpacing: 3, color: Colors.void, textTransform: 'uppercase' },
  skipText: { fontFamily: Typography.sans, fontSize: Typography.sm, color: Colors.textDim, textAlign: 'center', letterSpacing: 1 },
});
