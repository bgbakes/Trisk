// app/(auth)/signup.tsx
import { useState } from 'react';
import {
  View, Text, TextInput, StyleSheet, Pressable,
  KeyboardAvoidingView, Platform, ScrollView, Alert
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { signUp } from '@/lib/supabase';
import { Colors, Typography, Spacing, Radius, Gradients } from '@/lib/theme';
import type { DynamicRole } from '@/lib/types';

const ROLES: { value: DynamicRole; label: string; desc: string }[] = [
  { value: 'dominant',   label: 'Dominant',   desc: 'I lead the dynamic' },
  { value: 'submissive', label: 'Submissive',  desc: 'I follow the dynamic' },
  { value: 'switch',     label: 'Switch',      desc: 'I move between both' },
];

export default function SignupScreen() {
  const [step, setStep]         = useState<1 | 2>(1);
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [role, setRole]         = useState<DynamicRole | null>(null);
  const [loading, setLoading]   = useState(false);

  const handleNext = () => {
    if (!email || !password) {
      Alert.alert('Required', 'Enter email and password to continue.');
      return;
    }
    if (password.length < 8) {
      Alert.alert('Password too short', 'Use at least 8 characters.');
      return;
    }
    setStep(2);
  };

  const handleSignup = async () => {
    if (!username || !role) {
      Alert.alert('Required', 'Choose a username and your role.');
      return;
    }
    try {
      setLoading(true);
      await signUp(email.trim().toLowerCase(), password);
      router.replace('/(auth)/onboarding');
    } catch (err: any) {
      Alert.alert('Signup failed', err.message ?? 'Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1, backgroundColor: Colors.void }}
    >
      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
      >
        <Pressable style={styles.back} onPress={() => step === 1 ? router.back() : setStep(1)}>
          <Text style={styles.backText}>← {step === 1 ? 'Back' : 'Previous'}</Text>
        </Pressable>

        {/* Step indicator */}
        <View style={styles.steps}>
          {[1, 2].map((s) => (
            <View key={s} style={[styles.stepDot, step >= s && styles.stepActive]} />
          ))}
        </View>

        {step === 1 ? (
          <>
            <Text style={styles.heading}>Join{'\n'}the Scene</Text>
            <Text style={styles.sub}>Your kink community awaits.</Text>

            <View style={styles.form}>
              <View style={styles.field}>
                <Text style={styles.label}>Email</Text>
                <TextInput
                  style={styles.input}
                  value={email}
                  onChangeText={setEmail}
                  placeholder="your@email.com"
                  placeholderTextColor={Colors.textDim}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>
              <View style={styles.field}>
                <Text style={styles.label}>Password</Text>
                <TextInput
                  style={styles.input}
                  value={password}
                  onChangeText={setPassword}
                  placeholder="8+ characters"
                  placeholderTextColor={Colors.textDim}
                  secureTextEntry
                />
              </View>
            </View>

            <Pressable style={styles.btn} onPress={handleNext}>
              <LinearGradient colors={Gradients.goldShort} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.btnGradient}>
                <Text style={styles.btnText}>Continue</Text>
              </LinearGradient>
            </Pressable>
          </>
        ) : (
          <>
            <Text style={styles.heading}>Who{'\n'}Are You?</Text>
            <Text style={styles.sub}>Set your identity. You can change it later.</Text>

            <View style={styles.form}>
              <View style={styles.field}>
                <Text style={styles.label}>Username</Text>
                <TextInput
                  style={styles.input}
                  value={username}
                  onChangeText={setUsername}
                  placeholder="your_scene_name"
                  placeholderTextColor={Colors.textDim}
                  autoCapitalize="none"
                />
              </View>
            </View>

            <Text style={[styles.label, { marginBottom: Spacing.sm }]}>Your Role</Text>
            <View style={styles.roles}>
              {ROLES.map((r) => (
                <Pressable
                  key={r.value}
                  style={[styles.roleCard, role === r.value && styles.roleCardActive]}
                  onPress={() => setRole(r.value)}
                >
                  <Text style={[styles.roleLabel, role === r.value && styles.roleLabelActive]}>
                    {r.label}
                  </Text>
                  <Text style={styles.roleDesc}>{r.desc}</Text>
                </Pressable>
              ))}
            </View>

            <Pressable
              style={[styles.btn, loading && styles.btnDisabled]}
              onPress={handleSignup}
              disabled={loading}
            >
              <LinearGradient colors={Gradients.goldShort} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.btnGradient}>
                <Text style={styles.btnText}>{loading ? 'Creating...' : 'Enter Trisk'}</Text>
              </LinearGradient>
            </Pressable>
          </>
        )}

        <Pressable onPress={() => router.push('/(auth)/login')}>
          <Text style={styles.switchText}>
            Already a member?{' '}
            <Text style={styles.switchLink}>Sign in</Text>
          </Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, backgroundColor: Colors.void, padding: Spacing['2xl'], justifyContent: 'center' },
  back: { marginBottom: Spacing['2xl'] },
  backText: { fontFamily: Typography.sans, fontSize: Typography.base, color: Colors.textMuted, letterSpacing: 1 },
  steps: { flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing['2xl'] },
  stepDot: { width: 24, height: 3, borderRadius: 2, backgroundColor: Colors.textDim },
  stepActive: { backgroundColor: Colors.goldBright },
  heading: { fontFamily: Typography.display, fontSize: Typography['3xl'], color: Colors.goldBright, letterSpacing: 2, marginBottom: Spacing.sm, lineHeight: Typography['3xl'] * 1.15 },
  sub: { fontFamily: Typography.serifItalic, fontSize: Typography.md, color: Colors.textMuted, marginBottom: Spacing['2xl'] },
  form: { gap: Spacing.base, marginBottom: Spacing.lg },
  field: { gap: Spacing.xs },
  label: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 2, textTransform: 'uppercase', color: Colors.textMuted },
  input: { backgroundColor: Colors.leather, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: Spacing.base, fontFamily: Typography.sans, fontSize: Typography.base, color: Colors.textPrimary },
  roles: { gap: Spacing.sm, marginBottom: Spacing['2xl'] },
  roleCard: { borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: Spacing.base, backgroundColor: Colors.leather },
  roleCardActive: { borderColor: Colors.goldBright, backgroundColor: 'rgba(196,154,42,0.1)' },
  roleLabel: { fontFamily: Typography.display, fontSize: Typography.base, color: Colors.textMuted, letterSpacing: 2, marginBottom: 4 },
  roleLabelActive: { color: Colors.goldBright },
  roleDesc: { fontFamily: Typography.sans, fontSize: Typography.sm, color: Colors.textDim },
  btn: { borderRadius: Radius.md, overflow: 'hidden', marginBottom: Spacing.xl },
  btnDisabled: { opacity: 0.6 },
  btnGradient: { paddingVertical: Spacing.base, alignItems: 'center', borderRadius: Radius.md },
  btnText: { fontFamily: Typography.display, fontSize: Typography.base, letterSpacing: 3, color: Colors.void, textTransform: 'uppercase' },
  switchText: { fontFamily: Typography.sans, fontSize: Typography.sm, color: Colors.textMuted, textAlign: 'center' },
  switchLink: { color: Colors.goldBright },
});
