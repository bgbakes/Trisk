// app/(auth)/welcome.tsx
import { View, Text, StyleSheet, Pressable, Dimensions } from 'react-native';
import Svg, { Path, Circle, Defs, RadialGradient, Stop, ClipPath } from 'react-native-svg';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Colors, Typography, Spacing, Radius, Gradients } from '@/lib/theme';

const { width, height } = Dimensions.get('window');


// ── Inline SVG Triskelion Logo (no asset file required) ──────────
function TriskelionLogo({ size = 200 }: { size?: number }) {
  const cx = size / 2;
  const cy = size / 2;

  // Archimedean spiral arm path — computed for this size
  // Each arm starts at center and spirals outward, rotated 120deg apart
  const armPath = (rotation: number) => {
    const steps = 80;
    const innerR = (size * 0.06);
    const outerR = (size * 0.405);
    const sweep = Math.PI * 1.55;
    const b = (outerR - innerR) / sweep;
    const startAngle = -Math.PI / 2 + (rotation * Math.PI / 180);
    let d = '';
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const theta = t * sweep;
      const r = innerR + b * theta;
      const angle = startAngle - theta;
      const x = (cx + r * Math.cos(angle)).toFixed(2);
      const y = (cy + r * Math.sin(angle)).toFixed(2);
      d += (i === 0 ? `M ${x} ${y} ` : `L ${x} ${y} `);
    }
    return d;
  };

  const strokeW = size * 0.075;

  return (
    <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <Defs>
        <RadialGradient id="goldGrad" cx="50%" cy="50%" r="50%">
          <Stop offset="0%" stopColor="#F7E88A" />
          <Stop offset="35%" stopColor="#E8C244" />
          <Stop offset="70%" stopColor="#C49A2A" />
          <Stop offset="100%" stopColor="#7A5010" />
        </RadialGradient>
        <ClipPath id="circleClip">
          <Circle cx={cx} cy={cy} r={size * 0.445} />
        </ClipPath>
      </Defs>
      {/* Outer rings */}
      <Circle cx={cx} cy={cy} r={size * 0.47} fill="none" stroke="#C49A2A" strokeWidth={1} opacity={0.4} />
      <Circle cx={cx} cy={cy} r={size * 0.445} fill="none" stroke="#C49A2A" strokeWidth={0.5} opacity={0.25} />
      {/* Dark background */}
      <Circle cx={cx} cy={cy} r={size * 0.44} fill="#0E0A02" />
      {/* Three spiral arms */}
      <Path d={armPath(0)}   fill="none" stroke="url(#goldGrad)" strokeWidth={strokeW} strokeLinecap="round" clipPath="url(#circleClip)" />
      <Path d={armPath(120)} fill="none" stroke="url(#goldGrad)" strokeWidth={strokeW} strokeLinecap="round" clipPath="url(#circleClip)" />
      <Path d={armPath(240)} fill="none" stroke="url(#goldGrad)" strokeWidth={strokeW} strokeLinecap="round" clipPath="url(#circleClip)" />
      {/* Center hub */}
      <Circle cx={cx} cy={cy} r={size * 0.065} fill="#E8C244" />
      <Circle cx={cx} cy={cy} r={size * 0.025} fill="#FEFAEC" />
    </Svg>
  );
}

export default function WelcomeScreen() {
  return (
    <LinearGradient
      colors={['#1a0d02', '#0E0A02', Colors.void]}
      locations={[0, 0.4, 1]}
      style={styles.container}
    >
      {/* Background glow */}
      <View style={styles.glowBg} />

      {/* Logo */}
      <View style={styles.logoWrap}>
        <TriskelionLogo size={200} />
      </View>

      {/* Tagline */}
      <View style={styles.taglineWrap}>
        <Text style={styles.tagline}>Power. Trust. Dynamic.</Text>
        <Text style={styles.sub}>
          Track your dynamic. Find your scene.{'\n'}Live your truth.
        </Text>
      </View>

      {/* Three spiral labels */}
      <View style={styles.pillars}>
        {[
          { icon: '⚯', label: 'Connect' },
          { icon: '◈', label: 'Track'   },
          { icon: '⊕', label: 'Thrive'  },
        ].map((p) => (
          <View key={p.label} style={styles.pillar}>
            <Text style={styles.pillarIcon}>{p.icon}</Text>
            <Text style={styles.pillarLabel}>{p.label}</Text>
          </View>
        ))}
      </View>

      {/* CTAs */}
      <View style={styles.ctas}>
        <Pressable
          style={({ pressed }) => [styles.btnPrimary, pressed && styles.pressed]}
          onPress={() => router.push('/(auth)/signup')}
        >
          <LinearGradient
            colors={Gradients.goldShort}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            style={styles.btnGradient}
          >
            <Text style={styles.btnPrimaryText}>Enter the Scene</Text>
          </LinearGradient>
        </Pressable>

        <Pressable
          style={({ pressed }) => [styles.btnSecondary, pressed && styles.pressed]}
          onPress={() => router.push('/(auth)/login')}
        >
          <Text style={styles.btnSecondaryText}>I have an account</Text>
        </Pressable>
      </View>

      {/* Disclaimer */}
      <Text style={styles.disclaimer}>
        18+ only · Adults only · All kinks consensual
      </Text>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: Spacing['2xl'],
  },
  glowBg: {
    position: 'absolute',
    top: height * 0.15,
    width: 300,
    height: 300,
    borderRadius: 150,
    backgroundColor: 'rgba(196,154,42,0.06)',
  },
  logoWrap: {
    marginBottom: Spacing['3xl'],
    alignItems: 'center',
  },
  // logo style handled by TriskelionLogo component directly
  taglineWrap: {
    alignItems: 'center',
    marginBottom: Spacing['3xl'],
  },
  tagline: {
    fontFamily: Typography.display,
    fontSize: Typography.lg,
    letterSpacing: 4,
    color: Colors.goldBright,
    textAlign: 'center',
    marginBottom: Spacing.md,
  },
  sub: {
    fontFamily: Typography.serifItalic,
    fontSize: Typography.md,
    color: Colors.textMuted,
    textAlign: 'center',
    lineHeight: Typography.md * Typography.loose,
  },
  pillars: {
    flexDirection: 'row',
    gap: Spacing['2xl'],
    marginBottom: Spacing['4xl'],
  },
  pillar: {
    alignItems: 'center',
    gap: Spacing.xs,
  },
  pillarIcon: {
    fontSize: 20,
    color: Colors.goldBright,
  },
  pillarLabel: {
    fontFamily: Typography.sans,
    fontSize: Typography.xs,
    letterSpacing: 3,
    textTransform: 'uppercase',
    color: Colors.textMuted,
  },
  ctas: {
    width: '100%',
    gap: Spacing.md,
    marginBottom: Spacing['2xl'],
  },
  btnPrimary: {
    borderRadius: Radius.md,
    overflow: 'hidden',
  },
  btnGradient: {
    paddingVertical: Spacing.base,
    alignItems: 'center',
    borderRadius: Radius.md,
  },
  btnPrimaryText: {
    fontFamily: Typography.display,
    fontSize: Typography.base,
    letterSpacing: 3,
    color: Colors.void,
    textTransform: 'uppercase',
  },
  btnSecondary: {
    paddingVertical: Spacing.base,
    alignItems: 'center',
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  btnSecondaryText: {
    fontFamily: Typography.sans,
    fontSize: Typography.base,
    color: Colors.textMuted,
    letterSpacing: 1,
  },
  pressed: {
    opacity: 0.8,
    transform: [{ scale: 0.98 }],
  },
  disclaimer: {
    fontFamily: Typography.sans,
    fontSize: Typography.xs,
    color: Colors.textDim,
    letterSpacing: 1,
    textAlign: 'center',
  },
});
