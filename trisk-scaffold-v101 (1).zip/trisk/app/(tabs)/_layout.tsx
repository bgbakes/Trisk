// app/(tabs)/_layout.tsx
import { Tabs } from 'expo-router';
import { View, StyleSheet } from 'react-native';
import { BlurView } from 'expo-blur';
import { Colors, Typography } from '@/lib/theme';

// Tab icon component
function TabIcon({ symbol, focused }: { symbol: string; focused: boolean }) {
  return (
    <View style={[styles.iconWrap, focused && styles.iconActive]}>
      <View style={[styles.iconInner, focused && styles.iconInnerActive]}>
        <View style={[styles.symbol, { opacity: focused ? 1 : 0.4 }]}>
          {/* SVG icons would go here — using text symbols as placeholders */}
        </View>
      </View>
    </View>
  );
}

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarBackground: () => (
          <BlurView
            intensity={80}
            tint="dark"
            style={StyleSheet.absoluteFill}
          />
        ),
        tabBarActiveTintColor: Colors.goldBright,
        tabBarInactiveTintColor: Colors.textDim,
        tabBarLabelStyle: styles.tabLabel,
        tabBarShowLabel: true,
      }}
    >
      <Tabs.Screen
        name="connect"
        options={{
          title: 'Connect',
          tabBarIcon: ({ focused }) => (
            <TabIcon symbol="⚯" focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="track"
        options={{
          title: 'Track',
          tabBarIcon: ({ focused }) => (
            <TabIcon symbol="◈" focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="scene"
        options={{
          title: 'Scene',
          tabBarIcon: ({ focused }) => (
            <TabIcon symbol="⊕" focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Profile',
          tabBarIcon: ({ focused }) => (
            <TabIcon symbol="○" focused={focused} />
          ),
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    position: 'absolute',
    borderTopWidth: 1,
    borderTopColor: 'rgba(196,154,42,0.2)',
    backgroundColor: 'transparent',
    height: 84,
    paddingBottom: 24,
    paddingTop: 8,
  },
  tabLabel: {
    fontFamily: Typography.sans,
    fontSize: 10,
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  iconWrap: {
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconActive: {},
  iconInner: {
    width: 28,
    height: 28,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconInnerActive: {
    backgroundColor: 'rgba(196,154,42,0.15)',
  },
  symbol: {},
});
