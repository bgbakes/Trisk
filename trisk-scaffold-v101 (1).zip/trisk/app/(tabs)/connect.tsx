// app/(tabs)/connect.tsx
// Connect Tab — Dating / Discovery / Matches / Messages

import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, FlatList } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Typography, Spacing, Radius, Shadow } from '@/lib/theme';

type ConnectView = 'discover' | 'matches' | 'messages';

// ── Placeholder data ──────────────────────────────────────────────
const MOCK_PROFILES = [
  { id: '1', name: 'Sir_Marcus', role: 'dominant',   age: 38, location: 'Las Vegas, NV', bio: 'Old Guard leather. 15 yrs experience. Seeking serious dynamic.', looking_for: ['submissive'] },
  { id: '2', name: 'littlerose',  role: 'submissive', age: 26, location: 'Henderson, NV', bio: 'DD/lg little seeking a patient, caring Daddy Dom.', looking_for: ['dominant'] },
  { id: '3', name: 'PetKira',     role: 'submissive', age: 31, location: 'Las Vegas, NV', bio: 'Kitten seeking an Owner. Pet play & light bondage.', looking_for: ['dominant'] },
];

const MOCK_MATCHES = [
  { id: 'm1', name: 'DomVictor',   last_msg: 'Would love to chat about protocols...', time: '2m', unread: 2 },
  { id: 'm2', name: 'BabyGirlSky', last_msg: 'I love that you mentioned aftercare 🖤', time: '1h', unread: 0 },
];

const ROLE_COLOR: Record<string, string> = {
  dominant:   Colors.goldBright,
  submissive: '#C4B5FD',
  switch:     '#6EE7B7',
};

export default function ConnectScreen() {
  const [view, setView] = useState<ConnectView>('discover');
  const [cardIndex, setCardIndex] = useState(0);

  const currentProfile = MOCK_PROFILES[cardIndex];

  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient colors={['#160e04', Colors.void]} style={styles.header}>
        <Text style={styles.logo}>TRISK</Text>
        <Text style={styles.headerSub}>Connect</Text>
      </LinearGradient>

      {/* Sub-nav */}
      <View style={styles.subnav}>
        {(['discover', 'matches', 'messages'] as ConnectView[]).map((v) => (
          <Pressable key={v} style={[styles.subnavItem, view === v && styles.subnavActive]} onPress={() => setView(v)}>
            <Text style={[styles.subnavText, view === v && styles.subnavTextActive]}>
              {v.charAt(0).toUpperCase() + v.slice(1)}
            </Text>
          </Pressable>
        ))}
      </View>

      {/* ── DISCOVER ── */}
      {view === 'discover' && currentProfile && (
        <View style={styles.discoverWrap}>
          <View style={styles.profileCard}>
            {/* Photo placeholder */}
            <LinearGradient colors={['#1C1208', '#0E0A02']} style={styles.photoPlaceholder}>
              <Text style={styles.photoInitial}>{currentProfile.name[0].toUpperCase()}</Text>
              <View style={styles.roleChip}>
                <Text style={[styles.roleChipText, { color: ROLE_COLOR[currentProfile.role] }]}>
                  {currentProfile.role}
                </Text>
              </View>
            </LinearGradient>

            {/* Info */}
            <View style={styles.cardInfo}>
              <View style={styles.cardNameRow}>
                <Text style={styles.cardName}>{currentProfile.name}</Text>
                <Text style={styles.cardAge}>{currentProfile.age}</Text>
              </View>
              <Text style={styles.cardLocation}>📍 {currentProfile.location}</Text>
              <Text style={styles.cardBio}>{currentProfile.bio}</Text>
              <Text style={styles.cardLooking}>
                Seeking: {currentProfile.looking_for.join(', ')}
              </Text>
            </View>
          </View>

          {/* Action buttons */}
          <View style={styles.actions}>
            <Pressable style={styles.passBtn} onPress={() => setCardIndex(i => Math.min(i + 1, MOCK_PROFILES.length - 1))}>
              <Text style={styles.passBtnText}>✕ Pass</Text>
            </Pressable>
            <Pressable style={styles.likeBtn}>
              <LinearGradient colors={['#E8C244', '#C49A2A']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.likeBtnGrad}>
                <Text style={styles.likeBtnText}>♥ Connect</Text>
              </LinearGradient>
            </Pressable>
          </View>

          <Text style={styles.matchCount}>{MOCK_PROFILES.length - cardIndex} profiles nearby</Text>
        </View>
      )}

      {/* ── MATCHES ── */}
      {view === 'matches' && (
        <ScrollView style={styles.listWrap} contentContainerStyle={{ paddingBottom: 100 }}>
          <Text style={styles.sectionTitle}>Your Connections</Text>
          {MOCK_MATCHES.map((m) => (
            <Pressable key={m.id} style={styles.matchRow}>
              <View style={styles.matchAvatar}>
                <Text style={styles.matchInitial}>{m.name[0]}</Text>
              </View>
              <View style={styles.matchInfo}>
                <Text style={styles.matchName}>{m.name}</Text>
                <Text style={styles.matchMsg} numberOfLines={1}>{m.last_msg}</Text>
              </View>
              <View style={styles.matchMeta}>
                <Text style={styles.matchTime}>{m.time}</Text>
                {m.unread > 0 && (
                  <View style={styles.unreadBadge}>
                    <Text style={styles.unreadText}>{m.unread}</Text>
                  </View>
                )}
              </View>
            </Pressable>
          ))}
        </ScrollView>
      )}

      {/* ── MESSAGES ── */}
      {view === 'messages' && (
        <View style={styles.emptyState}>
          <Text style={styles.emptyIcon}>◯</Text>
          <Text style={styles.emptyTitle}>No messages yet</Text>
          <Text style={styles.emptyText}>Connect with someone to start a conversation.</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.void },
  header: { paddingTop: 56, paddingBottom: Spacing.base, paddingHorizontal: Spacing['2xl'], flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  logo: { fontFamily: Typography.display, fontSize: Typography.lg, letterSpacing: 4, color: Colors.goldBright },
  headerSub: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 3, textTransform: 'uppercase', color: Colors.textMuted },
  subnav: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: Colors.border, backgroundColor: Colors.darkLeather },
  subnavItem: { flex: 1, paddingVertical: Spacing.md, alignItems: 'center' },
  subnavActive: { borderBottomWidth: 2, borderBottomColor: Colors.goldBright },
  subnavText: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 2, textTransform: 'uppercase', color: Colors.textMuted },
  subnavTextActive: { color: Colors.goldBright },
  discoverWrap: { flex: 1, padding: Spacing.base, paddingBottom: 100 },
  profileCard: { flex: 1, borderRadius: Radius.xl, overflow: 'hidden', borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.leather, ...Shadow.dark },
  photoPlaceholder: { height: 320, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  photoInitial: { fontFamily: Typography.display, fontSize: 80, color: Colors.goldBright, opacity: 0.3 },
  roleChip: { position: 'absolute', top: Spacing.base, right: Spacing.base, paddingHorizontal: Spacing.sm, paddingVertical: 4, borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border, backgroundColor: 'rgba(8,8,6,0.7)' },
  roleChipText: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 2, textTransform: 'uppercase' },
  cardInfo: { padding: Spacing.base, gap: Spacing.xs },
  cardNameRow: { flexDirection: 'row', alignItems: 'baseline', gap: Spacing.sm },
  cardName: { fontFamily: Typography.display, fontSize: Typography.xl, color: Colors.cream, letterSpacing: 1 },
  cardAge: { fontFamily: Typography.sans, fontSize: Typography.base, color: Colors.textMuted },
  cardLocation: { fontFamily: Typography.sans, fontSize: Typography.sm, color: Colors.textMuted },
  cardBio: { fontFamily: Typography.serifItalic, fontSize: Typography.base, color: Colors.cream, lineHeight: Typography.base * 1.6 },
  cardLooking: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.goldDeep, letterSpacing: 1, textTransform: 'uppercase' },
  actions: { flexDirection: 'row', gap: Spacing.md, marginTop: Spacing.md },
  passBtn: { flex: 1, paddingVertical: Spacing.base, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border, alignItems: 'center' },
  passBtnText: { fontFamily: Typography.sans, fontSize: Typography.base, color: Colors.textMuted, letterSpacing: 1 },
  likeBtn: { flex: 2, borderRadius: Radius.md, overflow: 'hidden' },
  likeBtnGrad: { paddingVertical: Spacing.base, alignItems: 'center' },
  likeBtnText: { fontFamily: Typography.display, fontSize: Typography.base, letterSpacing: 2, color: Colors.void },
  matchCount: { textAlign: 'center', fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textDim, letterSpacing: 1, marginTop: Spacing.sm },
  listWrap: { flex: 1 },
  sectionTitle: { fontFamily: Typography.display, fontSize: Typography.base, letterSpacing: 3, color: Colors.goldBright, padding: Spacing.base, textTransform: 'uppercase' },
  matchRow: { flexDirection: 'row', padding: Spacing.base, borderBottomWidth: 1, borderBottomColor: Colors.border, gap: Spacing.md, alignItems: 'center' },
  matchAvatar: { width: 48, height: 48, borderRadius: 24, backgroundColor: Colors.leather, borderWidth: 1, borderColor: Colors.border, alignItems: 'center', justifyContent: 'center' },
  matchInitial: { fontFamily: Typography.display, fontSize: Typography.lg, color: Colors.goldBright },
  matchInfo: { flex: 1 },
  matchName: { fontFamily: Typography.display, fontSize: Typography.base, color: Colors.cream, letterSpacing: 1, marginBottom: 2 },
  matchMsg: { fontFamily: Typography.sans, fontSize: Typography.sm, color: Colors.textMuted },
  matchMeta: { alignItems: 'flex-end', gap: Spacing.xs },
  matchTime: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textDim },
  unreadBadge: { width: 18, height: 18, borderRadius: 9, backgroundColor: Colors.goldBright, alignItems: 'center', justifyContent: 'center' },
  unreadText: { fontFamily: Typography.sans, fontSize: 10, color: Colors.void, fontWeight: '700' },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing['3xl'] },
  emptyIcon: { fontSize: 48, color: Colors.textDim, marginBottom: Spacing.base },
  emptyTitle: { fontFamily: Typography.display, fontSize: Typography.xl, color: Colors.goldBright, letterSpacing: 2, marginBottom: Spacing.sm },
  emptyText: { fontFamily: Typography.serifItalic, fontSize: Typography.base, color: Colors.textMuted, textAlign: 'center' },
});
