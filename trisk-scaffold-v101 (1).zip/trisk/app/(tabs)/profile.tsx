// app/(tabs)/profile.tsx
import { View, Text, StyleSheet, ScrollView, Pressable, Switch, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { signOut } from '@/lib/supabase';
import { Colors, Typography, Spacing, Radius, Gradients } from '@/lib/theme';
import { useState } from 'react';

const MOCK_PROFILE = {
  username: 'littlerose',
  display_name: 'Rose',
  role: 'submissive',
  dynamic_type: 'D/s',
  is_collared: true,
  is_premium: false,
  location: 'Las Vegas, NV',
  bio: 'DD/lg little. Lover of soft things and strict protocols.',
  streak: 14,
  tasks_completed: 287,
  matches: 3,
};

export default function ProfileScreen() {
  const [discreet, setDiscreet]     = useState(false);
  const [collarVisible, setCollarVisible] = useState(true);

  const handleSignOut = async () => {
    Alert.alert('Sign Out', 'Leave the scene?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign Out',
        style: 'destructive',
        onPress: async () => {
          try { await signOut(); } catch (e) {}
        },
      },
    ]);
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#160e04', Colors.void]} style={styles.header}>
        <Text style={styles.logo}>TRISK</Text>
        <Text style={styles.headerSub}>Profile</Text>
      </LinearGradient>

      <ScrollView contentContainerStyle={{ paddingBottom: 100 }}>

        {/* Profile hero */}
        <LinearGradient colors={['rgba(196,154,42,0.12)', 'transparent']} style={styles.profileHero}>
          <View style={styles.avatarWrap}>
            <View style={styles.avatar}>
              <Text style={styles.avatarInitial}>{MOCK_PROFILE.username[0].toUpperCase()}</Text>
            </View>
            {MOCK_PROFILE.is_collared && (
              <View style={styles.collarBadge}>
                <Text style={styles.collarBadgeText}>⊙</Text>
              </View>
            )}
          </View>
          <Text style={styles.displayName}>{MOCK_PROFILE.display_name}</Text>
          <Text style={styles.username}>@{MOCK_PROFILE.username}</Text>
          <View style={styles.rolePill}>
            <Text style={styles.rolePillText}>{MOCK_PROFILE.role} · {MOCK_PROFILE.dynamic_type}</Text>
          </View>
          <Text style={styles.bio}>{MOCK_PROFILE.bio}</Text>

          {/* Stats */}
          <View style={styles.statsRow}>
            {[
              { v: MOCK_PROFILE.streak,          l: 'Day Streak' },
              { v: MOCK_PROFILE.tasks_completed,  l: 'Tasks Done' },
              { v: MOCK_PROFILE.matches,          l: 'Connections' },
            ].map((s) => (
              <View key={s.l} style={styles.statCell}>
                <Text style={styles.statVal}>{s.v}</Text>
                <Text style={styles.statLbl}>{s.l}</Text>
              </View>
            ))}
          </View>
        </LinearGradient>

        {/* Upgrade */}
        {!MOCK_PROFILE.is_premium && (
          <Pressable style={styles.upgradeCard}>
            <LinearGradient colors={Gradients.gold} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.upgradeGrad}>
              <View>
                <Text style={styles.upgradeTitle}>Upgrade to Pro</Text>
                <Text style={styles.upgradeSub}>Unlimited matches · Full tracker · Priority access</Text>
              </View>
              <Text style={styles.upgradePrice}>$9.99/mo</Text>
            </LinearGradient>
          </Pressable>
        )}

        {/* Privacy settings */}
        <Text style={styles.sectionTitle}>Privacy</Text>
        <View style={styles.settingsCard}>
          <View style={styles.settingRow}>
            <View>
              <Text style={styles.settingLabel}>Discreet Mode</Text>
              <Text style={styles.settingDesc}>Hide profile from non-members</Text>
            </View>
            <Switch
              value={discreet}
              onValueChange={setDiscreet}
              trackColor={{ false: Colors.border, true: Colors.gold }}
              thumbColor={discreet ? Colors.goldBright : Colors.textDim}
            />
          </View>
          <View style={[styles.settingRow, { borderTopWidth: 1, borderTopColor: Colors.border }]}>
            <View>
              <Text style={styles.settingLabel}>Show Collar Status</Text>
              <Text style={styles.settingDesc}>Display collared badge publicly</Text>
            </View>
            <Switch
              value={collarVisible}
              onValueChange={setCollarVisible}
              trackColor={{ false: Colors.border, true: Colors.gold }}
              thumbColor={collarVisible ? Colors.goldBright : Colors.textDim}
            />
          </View>
        </View>

        {/* Settings links */}
        <Text style={styles.sectionTitle}>Account</Text>
        <View style={styles.settingsCard}>
          {['Edit Profile', 'Notification Settings', 'Blocked Users', 'Data & Privacy', 'Help & Support'].map((item, i) => (
            <Pressable
              key={item}
              style={[styles.linkRow, i > 0 && { borderTopWidth: 1, borderTopColor: Colors.border }]}
            >
              <Text style={styles.linkText}>{item}</Text>
              <Text style={styles.linkArrow}>›</Text>
            </Pressable>
          ))}
        </View>

        {/* Sign out */}
        <Pressable style={styles.signOutBtn} onPress={handleSignOut}>
          <Text style={styles.signOutText}>Sign Out</Text>
        </Pressable>

        <Text style={styles.version}>Trisk v1.0.0 · trisk.app · © 2025 Mestre'K Enterprises LLC</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.void },
  header: { paddingTop: 56, paddingBottom: Spacing.base, paddingHorizontal: Spacing['2xl'], flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  logo: { fontFamily: Typography.display, fontSize: Typography.lg, letterSpacing: 4, color: Colors.goldBright },
  headerSub: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 3, textTransform: 'uppercase', color: Colors.textMuted },
  profileHero: { padding: Spacing['2xl'], alignItems: 'center', borderBottomWidth: 1, borderBottomColor: Colors.border },
  avatarWrap: { position: 'relative', marginBottom: Spacing.md },
  avatar: { width: 80, height: 80, borderRadius: 40, backgroundColor: Colors.leather, borderWidth: 2, borderColor: Colors.goldBright, alignItems: 'center', justifyContent: 'center' },
  avatarInitial: { fontFamily: Typography.display, fontSize: Typography['3xl'], color: Colors.goldBright },
  collarBadge: { position: 'absolute', bottom: 0, right: 0, width: 22, height: 22, borderRadius: 11, backgroundColor: Colors.goldBright, alignItems: 'center', justifyContent: 'center' },
  collarBadgeText: { fontSize: 10, color: Colors.void },
  displayName: { fontFamily: Typography.display, fontSize: Typography.xl, color: Colors.goldBright, letterSpacing: 2, marginBottom: 4 },
  username: { fontFamily: Typography.sans, fontSize: Typography.sm, color: Colors.textMuted, marginBottom: Spacing.sm },
  rolePill: { paddingHorizontal: Spacing.md, paddingVertical: 4, borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.md },
  rolePillText: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textMuted, letterSpacing: 2, textTransform: 'uppercase' },
  bio: { fontFamily: Typography.serifItalic, fontSize: Typography.base, color: Colors.cream, textAlign: 'center', lineHeight: Typography.base * 1.6, marginBottom: Spacing.lg },
  statsRow: { flexDirection: 'row', gap: Spacing.xl },
  statCell: { alignItems: 'center' },
  statVal: { fontFamily: Typography.display, fontSize: Typography.xl, color: Colors.goldBright },
  statLbl: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textMuted, letterSpacing: 1 },
  upgradeCard: { margin: Spacing.base, borderRadius: Radius.lg, overflow: 'hidden' },
  upgradeGrad: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: Spacing.base + 4 },
  upgradeTitle: { fontFamily: Typography.display, fontSize: Typography.base, color: Colors.void, letterSpacing: 2, marginBottom: 4 },
  upgradeSub: { fontFamily: Typography.sans, fontSize: Typography.xs, color: 'rgba(8,8,6,0.7)', letterSpacing: 0.5 },
  upgradePrice: { fontFamily: Typography.display, fontSize: Typography.xl, color: Colors.void },
  sectionTitle: { fontFamily: Typography.display, fontSize: Typography.xs, letterSpacing: 3, color: Colors.goldBright, paddingHorizontal: Spacing.base, paddingVertical: Spacing.sm, textTransform: 'uppercase' },
  settingsCard: { marginHorizontal: Spacing.base, marginBottom: Spacing.base, backgroundColor: Colors.leather, borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border, overflow: 'hidden' },
  settingRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: Spacing.base },
  settingLabel: { fontFamily: Typography.sans, fontSize: Typography.base, color: Colors.cream },
  settingDesc: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textMuted, marginTop: 2 },
  linkRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: Spacing.base },
  linkText: { fontFamily: Typography.sans, fontSize: Typography.base, color: Colors.cream },
  linkArrow: { fontFamily: Typography.sans, fontSize: Typography.xl, color: Colors.textDim },
  signOutBtn: { margin: Spacing.base, padding: Spacing.base, borderRadius: Radius.md, borderWidth: 1, borderColor: 'rgba(239,68,68,0.3)', alignItems: 'center' },
  signOutText: { fontFamily: Typography.sans, fontSize: Typography.base, color: Colors.error, letterSpacing: 1 },
  version: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textDim, textAlign: 'center', padding: Spacing.base, letterSpacing: 1 },
});
