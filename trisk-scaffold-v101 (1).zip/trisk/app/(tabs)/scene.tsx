// app/(tabs)/scene.tsx
// Scene Tab — Community feed, posts, events, munches

import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Typography, Spacing, Radius } from '@/lib/theme';

const MOCK_POSTS = [
  {
    id: '1', author: 'Sir_Marcus', role: 'dominant', time: '2h',
    content: 'Reminder: aftercare isn\'t optional. It\'s the most important part of the scene. Non-negotiable.',
    upvotes: 47, comments: 12, tags: ['aftercare', 'protocol'],
  },
  {
    id: '2', author: 'littlerose', role: 'submissive', time: '5h',
    content: 'Anyone else in the Las Vegas DD/lg community? Looking for local munches 🖤',
    upvotes: 23, comments: 18, tags: ['DD/lg', 'LasVegas', 'munch'],
  },
  {
    id: '3', author: 'TheLVLeatherSociety', role: 'community', time: '1d',
    content: '📍 Monthly Las Vegas Munch — Saturday, 7pm. DM for location. All dynamics welcome. Vanilla-friendly venue.',
    upvotes: 89, comments: 34, tags: ['munch', 'LasVegas', 'event'],
  },
];

const ROLE_COLOR: Record<string, string> = {
  dominant:   Colors.goldBright,
  submissive: '#C4B5FD',
  switch:     '#6EE7B7',
  community:  Colors.info,
};

export default function SceneScreen() {
  const [posts, setPosts] = useState(MOCK_POSTS);

  const upvote = (id: string) => {
    setPosts(prev => prev.map(p => p.id === id ? { ...p, upvotes: p.upvotes + 1 } : p));
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#160e04', Colors.void]} style={styles.header}>
        <Text style={styles.logo}>TRISK</Text>
        <Text style={styles.headerSub}>The Scene</Text>
      </LinearGradient>

      <ScrollView style={styles.body} contentContainerStyle={{ paddingBottom: 100 }}>

        {/* Post composer */}
        <Pressable style={styles.composer}>
          <View style={styles.composerAvatar} />
          <Text style={styles.composerPlaceholder}>Share with the scene...</Text>
          <Pressable style={styles.composerPost}>
            <Text style={styles.composerPostText}>Post</Text>
          </Pressable>
        </Pressable>

        {/* Feed */}
        {posts.map((p) => (
          <View key={p.id} style={styles.postCard}>
            <View style={styles.postHeader}>
              <View style={styles.postAvatar}>
                <Text style={styles.postInitial}>{p.author[0].toUpperCase()}</Text>
              </View>
              <View style={styles.postMeta}>
                <Text style={styles.postAuthor}>{p.author}</Text>
                <Text style={[styles.postRole, { color: ROLE_COLOR[p.role] ?? Colors.textMuted }]}>
                  {p.role} · {p.time}
                </Text>
              </View>
            </View>
            <Text style={styles.postContent}>{p.content}</Text>
            <View style={styles.postTags}>
              {p.tags.map((t) => (
                <Text key={t} style={styles.postTag}>#{t}</Text>
              ))}
            </View>
            <View style={styles.postActions}>
              <Pressable style={styles.postAction} onPress={() => upvote(p.id)}>
                <Text style={styles.postActionText}>♥ {p.upvotes}</Text>
              </Pressable>
              <Pressable style={styles.postAction}>
                <Text style={styles.postActionText}>◎ {p.comments}</Text>
              </Pressable>
              <Pressable style={styles.postAction}>
                <Text style={styles.postActionText}>↗ Share</Text>
              </Pressable>
            </View>
          </View>
        ))}

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.void },
  header: { paddingTop: 56, paddingBottom: Spacing.base, paddingHorizontal: Spacing['2xl'], flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  logo: { fontFamily: Typography.display, fontSize: Typography.lg, letterSpacing: 4, color: Colors.goldBright },
  headerSub: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 3, textTransform: 'uppercase', color: Colors.textMuted },
  body: { flex: 1 },
  composer: { flexDirection: 'row', alignItems: 'center', margin: Spacing.base, padding: Spacing.base, backgroundColor: Colors.leather, borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border, gap: Spacing.md },
  composerAvatar: { width: 32, height: 32, borderRadius: 16, backgroundColor: Colors.darkLeather, borderWidth: 1, borderColor: Colors.border },
  composerPlaceholder: { flex: 1, fontFamily: Typography.sans, fontSize: Typography.base, color: Colors.textDim },
  composerPost: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: Radius.full, backgroundColor: 'rgba(196,154,42,0.15)', borderWidth: 1, borderColor: Colors.border },
  composerPostText: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.goldBright, letterSpacing: 1 },
  postCard: { marginHorizontal: Spacing.base, marginBottom: Spacing.sm, backgroundColor: Colors.leather, borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border, padding: Spacing.base },
  postHeader: { flexDirection: 'row', gap: Spacing.md, marginBottom: Spacing.sm, alignItems: 'center' },
  postAvatar: { width: 38, height: 38, borderRadius: 19, backgroundColor: Colors.darkLeather, borderWidth: 1, borderColor: Colors.border, alignItems: 'center', justifyContent: 'center' },
  postInitial: { fontFamily: Typography.display, fontSize: Typography.base, color: Colors.goldBright },
  postMeta: {},
  postAuthor: { fontFamily: Typography.display, fontSize: Typography.sm, color: Colors.cream, letterSpacing: 1 },
  postRole: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 1 },
  postContent: { fontFamily: Typography.serif, fontSize: Typography.base, color: Colors.cream, lineHeight: Typography.base * 1.6, marginBottom: Spacing.sm },
  postTags: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xs, marginBottom: Spacing.sm },
  postTag: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.goldDeep, letterSpacing: 1 },
  postActions: { flexDirection: 'row', gap: Spacing.xl, borderTopWidth: 1, borderTopColor: Colors.border, paddingTop: Spacing.sm },
  postAction: {},
  postActionText: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textMuted, letterSpacing: 1 },
});
