// app/(tabs)/track.tsx
// Track Tab — Dynamic Tracker: Tasks, Rules, Rituals, Journal, Check-in

import { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, Switch
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Typography, Spacing, Radius, Shadow } from '@/lib/theme';

type TrackView = 'overview' | 'tasks' | 'rules' | 'journal';

// ── Mock data ─────────────────────────────────────────────────────
const MOCK_TASKS = [
  { id: '1', title: 'Morning gratitude text', status: 'pending',   points: 5,  due: 'Today 9am'  },
  { id: '2', title: 'Evening check-in',       status: 'pending',   points: 5,  due: 'Today 9pm'  },
  { id: '3', title: 'Wear collar all day',    status: 'completed', points: 10, due: 'Today'       },
  { id: '4', title: 'Journal entry',          status: 'pending',   points: 8,  due: 'Tonight'     },
];

const MOCK_RULES = [
  { id: '1', title: 'Address Sir by title at all times', active: true,  category: 'protocol' },
  { id: '2', title: 'Ask permission before spending >$50', active: true, category: 'behavior' },
  { id: '3', title: 'No social media after 10pm',          active: true, category: 'behavior' },
  { id: '4', title: 'Daily stretching routine',            active: false, category: 'physical' },
];

const MOCK_DYNAMIC = {
  dom_title: 'Sir',
  sub_title:  'babygirl',
  dynamic_type: 'D/s',
  streak_days: 14,
  total_points: 287,
  tasks_today: 2,
  tasks_total: 4,
  collar_date: '2024-06-15',
};

export default function TrackScreen() {
  const [view, setView] = useState<TrackView>('overview');
  const [tasks, setTasks] = useState(MOCK_TASKS);
  const [checkinMood, setCheckinMood] = useState(7);

  const completedToday = tasks.filter(t => t.status === 'completed').length;
  const progressPct = (completedToday / MOCK_DYNAMIC.tasks_total) * 100;

  const toggleTask = (id: string) => {
    setTasks(prev => prev.map(t =>
      t.id === id ? { ...t, status: t.status === 'completed' ? 'pending' : 'completed' } : t
    ));
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient colors={['#160e04', Colors.void]} style={styles.header}>
        <Text style={styles.logo}>TRISK</Text>
        <Text style={styles.headerSub}>Track</Text>
      </LinearGradient>

      {/* Sub-nav */}
      <View style={styles.subnav}>
        {(['overview', 'tasks', 'rules', 'journal'] as TrackView[]).map((v) => (
          <Pressable key={v} style={[styles.subnavItem, view === v && styles.subnavActive]} onPress={() => setView(v)}>
            <Text style={[styles.subnavText, view === v && styles.subnavTextActive]}>
              {v.charAt(0).toUpperCase() + v.slice(1)}
            </Text>
          </Pressable>
        ))}
      </View>

      <ScrollView style={styles.body} contentContainerStyle={{ paddingBottom: 100 }}>

        {/* ── OVERVIEW ── */}
        {view === 'overview' && (
          <>
            {/* Dynamic banner */}
            <LinearGradient colors={['rgba(196,154,42,0.15)', 'rgba(196,154,42,0.03)']} style={styles.dynamicBanner}>
              <View style={styles.dynamicRow}>
                <View>
                  <Text style={styles.dynamicLabel}>Your Dynamic</Text>
                  <Text style={styles.dynamicTitle}>
                    {MOCK_DYNAMIC.dom_title} / {MOCK_DYNAMIC.sub_title}
                  </Text>
                  <Text style={styles.dynamicType}>{MOCK_DYNAMIC.dynamic_type}</Text>
                </View>
                <View style={styles.streakBadge}>
                  <Text style={styles.streakNum}>{MOCK_DYNAMIC.streak_days}</Text>
                  <Text style={styles.streakLabel}>day streak</Text>
                </View>
              </View>
            </LinearGradient>

            {/* Stats row */}
            <View style={styles.statsRow}>
              {[
                { value: MOCK_DYNAMIC.total_points, label: 'Points' },
                { value: `${completedToday}/${MOCK_DYNAMIC.tasks_total}`, label: 'Tasks Today' },
                { value: MOCK_DYNAMIC.streak_days, label: 'Streak' },
              ].map((s) => (
                <View key={s.label} style={styles.statCard}>
                  <Text style={styles.statValue}>{s.value}</Text>
                  <Text style={styles.statLabel}>{s.label}</Text>
                </View>
              ))}
            </View>

            {/* Progress bar */}
            <View style={styles.progressWrap}>
              <View style={styles.progressBar}>
                <LinearGradient
                  colors={['#E8C244', '#C49A2A']}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                  style={[styles.progressFill, { width: `${progressPct}%` as any }]}
                />
              </View>
              <Text style={styles.progressText}>{completedToday} of {MOCK_DYNAMIC.tasks_total} tasks done today</Text>
            </View>

            {/* Today's tasks preview */}
            <Text style={styles.sectionTitle}>Today's Protocols</Text>
            {tasks.slice(0, 3).map((t) => (
              <Pressable key={t.id} style={styles.taskRow} onPress={() => toggleTask(t.id)}>
                <View style={[styles.taskCheck, t.status === 'completed' && styles.taskCheckDone]}>
                  {t.status === 'completed' && <Text style={styles.checkmark}>✓</Text>}
                </View>
                <View style={styles.taskInfo}>
                  <Text style={[styles.taskTitle, t.status === 'completed' && styles.taskDone]}>{t.title}</Text>
                  <Text style={styles.taskDue}>{t.due}</Text>
                </View>
                <Text style={styles.taskPoints}>+{t.points}pts</Text>
              </Pressable>
            ))}

            {/* Check-in */}
            <Text style={styles.sectionTitle}>Daily Check-in</Text>
            <View style={styles.checkinCard}>
              <Text style={styles.checkinLabel}>Mood today</Text>
              <View style={styles.moodRow}>
                {[1,2,3,4,5,6,7,8,9,10].map((n) => (
                  <Pressable
                    key={n}
                    style={[styles.moodDot, checkinMood >= n && styles.moodDotActive]}
                    onPress={() => setCheckinMood(n)}
                  />
                ))}
              </View>
              <Text style={styles.moodScore}>{checkinMood}/10</Text>
            </View>
          </>
        )}

        {/* ── TASKS ── */}
        {view === 'tasks' && (
          <>
            <View style={styles.listHeader}>
              <Text style={styles.sectionTitle}>All Tasks</Text>
              <Pressable style={styles.addBtn}>
                <Text style={styles.addBtnText}>+ Add Task</Text>
              </Pressable>
            </View>
            {tasks.map((t) => (
              <Pressable key={t.id} style={styles.taskRow} onPress={() => toggleTask(t.id)}>
                <View style={[styles.taskCheck, t.status === 'completed' && styles.taskCheckDone]}>
                  {t.status === 'completed' && <Text style={styles.checkmark}>✓</Text>}
                </View>
                <View style={styles.taskInfo}>
                  <Text style={[styles.taskTitle, t.status === 'completed' && styles.taskDone]}>{t.title}</Text>
                  <Text style={styles.taskDue}>{t.due}</Text>
                </View>
                <Text style={styles.taskPoints}>+{t.points}pts</Text>
              </Pressable>
            ))}
          </>
        )}

        {/* ── RULES ── */}
        {view === 'rules' && (
          <>
            <View style={styles.listHeader}>
              <Text style={styles.sectionTitle}>Protocol Rules</Text>
              <Pressable style={styles.addBtn}>
                <Text style={styles.addBtnText}>+ Add Rule</Text>
              </Pressable>
            </View>
            {MOCK_RULES.map((r) => (
              <View key={r.id} style={styles.ruleRow}>
                <View style={styles.ruleInfo}>
                  <Text style={[styles.ruleTitle, !r.active && { opacity: 0.4 }]}>{r.title}</Text>
                  <Text style={styles.ruleCat}>{r.category}</Text>
                </View>
                <View style={[styles.ruleActive, r.active && styles.ruleActiveDot]} />
              </View>
            ))}
          </>
        )}

        {/* ── JOURNAL ── */}
        {view === 'journal' && (
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>◉</Text>
            <Text style={styles.emptyTitle}>Your Journal</Text>
            <Text style={styles.emptyText}>
              Record your dynamic experiences, reflections, and growth.
            </Text>
            <Pressable style={styles.startJournalBtn}>
              <LinearGradient colors={['#E8C244', '#C49A2A']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.startJournalGrad}>
                <Text style={styles.startJournalText}>Write First Entry</Text>
              </LinearGradient>
            </Pressable>
          </View>
        )}

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.void },
  header: { paddingTop: 56, paddingBottom: Spacing.base, paddingHorizontal: Spacing['2xl'], flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  logo: { fontFamily: Typography.display, fontSize: Typography.lg, letterSpacing: 4, color: Colors.goldBright },
  headerSub: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 3, textTransform: 'uppercase', color: Colors.textMuted },
  subnav: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: Colors.border, backgroundColor: Colors.darkLeather },
  subnavItem: { flex: 1, paddingVertical: Spacing.md, alignItems: 'center' },
  subnavActive: { borderBottomWidth: 2, borderBottomColor: Colors.goldBright },
  subnavText: { fontFamily: Typography.sans, fontSize: 9, letterSpacing: 1.5, textTransform: 'uppercase', color: Colors.textMuted },
  subnavTextActive: { color: Colors.goldBright },
  body: { flex: 1 },
  dynamicBanner: { margin: Spacing.base, borderRadius: Radius.lg, padding: Spacing.base, borderWidth: 1, borderColor: Colors.border },
  dynamicRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  dynamicLabel: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 2, textTransform: 'uppercase', color: Colors.textMuted, marginBottom: 4 },
  dynamicTitle: { fontFamily: Typography.display, fontSize: Typography.xl, color: Colors.goldBright, letterSpacing: 2 },
  dynamicType: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textMuted, letterSpacing: 1 },
  streakBadge: { alignItems: 'center', borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: Spacing.sm },
  streakNum: { fontFamily: Typography.display, fontSize: Typography['2xl'], color: Colors.goldBright },
  streakLabel: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textMuted, letterSpacing: 1 },
  statsRow: { flexDirection: 'row', gap: Spacing.sm, paddingHorizontal: Spacing.base, marginBottom: Spacing.base },
  statCard: { flex: 1, backgroundColor: Colors.leather, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border, padding: Spacing.sm, alignItems: 'center' },
  statValue: { fontFamily: Typography.display, fontSize: Typography.xl, color: Colors.goldBright },
  statLabel: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textMuted, letterSpacing: 1 },
  progressWrap: { paddingHorizontal: Spacing.base, marginBottom: Spacing.base },
  progressBar: { height: 4, backgroundColor: Colors.leather, borderRadius: 2, marginBottom: Spacing.xs },
  progressFill: { height: 4, borderRadius: 2 },
  progressText: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textMuted },
  sectionTitle: { fontFamily: Typography.display, fontSize: Typography.sm, letterSpacing: 3, color: Colors.goldBright, paddingHorizontal: Spacing.base, paddingVertical: Spacing.sm, textTransform: 'uppercase' },
  taskRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.border, gap: Spacing.md },
  taskCheck: { width: 22, height: 22, borderRadius: 11, borderWidth: 1.5, borderColor: Colors.border, alignItems: 'center', justifyContent: 'center' },
  taskCheckDone: { backgroundColor: Colors.goldBright, borderColor: Colors.goldBright },
  checkmark: { color: Colors.void, fontSize: 12, fontWeight: '700' },
  taskInfo: { flex: 1 },
  taskTitle: { fontFamily: Typography.sans, fontSize: Typography.base, color: Colors.cream },
  taskDone: { textDecorationLine: 'line-through', opacity: 0.4 },
  taskDue: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textMuted, marginTop: 2 },
  taskPoints: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.goldDeep, letterSpacing: 1 },
  checkinCard: { margin: Spacing.base, backgroundColor: Colors.leather, borderRadius: Radius.lg, padding: Spacing.base, borderWidth: 1, borderColor: Colors.border },
  checkinLabel: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 2, textTransform: 'uppercase', color: Colors.textMuted, marginBottom: Spacing.sm },
  moodRow: { flexDirection: 'row', gap: Spacing.xs, marginBottom: Spacing.xs },
  moodDot: { width: 22, height: 22, borderRadius: 11, backgroundColor: Colors.darkLeather, borderWidth: 1, borderColor: Colors.border },
  moodDotActive: { backgroundColor: Colors.goldBright, borderColor: Colors.goldBright },
  moodScore: { fontFamily: Typography.display, fontSize: Typography.lg, color: Colors.goldBright, letterSpacing: 2 },
  listHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingRight: Spacing.base },
  addBtn: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border },
  addBtnText: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.goldBright, letterSpacing: 1 },
  ruleRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.border, gap: Spacing.md },
  ruleInfo: { flex: 1 },
  ruleTitle: { fontFamily: Typography.sans, fontSize: Typography.base, color: Colors.cream },
  ruleCat: { fontFamily: Typography.sans, fontSize: Typography.xs, color: Colors.textMuted, textTransform: 'uppercase', letterSpacing: 1, marginTop: 2 },
  ruleActive: { width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.textDim },
  ruleActiveDot: { backgroundColor: Colors.success },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing['3xl'], marginTop: Spacing['4xl'] },
  emptyIcon: { fontSize: 48, color: Colors.textDim, marginBottom: Spacing.base },
  emptyTitle: { fontFamily: Typography.display, fontSize: Typography.xl, color: Colors.goldBright, letterSpacing: 2, marginBottom: Spacing.sm },
  emptyText: { fontFamily: Typography.serifItalic, fontSize: Typography.base, color: Colors.textMuted, textAlign: 'center', marginBottom: Spacing['2xl'] },
  startJournalBtn: { borderRadius: Radius.md, overflow: 'hidden' },
  startJournalGrad: { paddingHorizontal: Spacing['2xl'], paddingVertical: Spacing.base, alignItems: 'center' },
  startJournalText: { fontFamily: Typography.display, fontSize: Typography.sm, letterSpacing: 3, color: Colors.void, textTransform: 'uppercase' },
});
