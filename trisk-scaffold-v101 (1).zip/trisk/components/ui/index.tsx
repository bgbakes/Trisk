// components/ui/index.tsx
// Trisk — Shared UI Component Library

import {
  View, Text, StyleSheet, Pressable,
  TextInput, ActivityIndicator,
  type ViewStyle, type TextStyle, type PressableProps
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Typography, Spacing, Radius, Gradients, Shadow } from '@/lib/theme';

// ── BUTTON ────────────────────────────────────────────────────────

interface ButtonProps extends PressableProps {
  label: string;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  fullWidth?: boolean;
}

export function Button({
  label,
  variant = 'primary',
  size = 'md',
  loading = false,
  fullWidth = false,
  disabled,
  onPress,
  style,
  ...rest
}: ButtonProps) {
  const isDisabled = disabled || loading;

  const sizeMap = {
    sm: { paddingV: Spacing.xs,   fontSize: Typography.xs,   letterSpacing: 2 },
    md: { paddingV: Spacing.base, fontSize: Typography.base, letterSpacing: 3 },
    lg: { paddingV: Spacing.lg,   fontSize: Typography.md,   letterSpacing: 4 },
  };

  const sz = sizeMap[size];

  if (variant === 'primary') {
    return (
      <Pressable
        onPress={onPress}
        disabled={isDisabled}
        style={[
          styles.btnBase,
          fullWidth && styles.fullWidth,
          isDisabled && styles.disabled,
          style as ViewStyle,
        ]}
        {...rest}
      >
        <LinearGradient
          colors={Gradients.goldShort}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
          style={[styles.btnGrad, { paddingVertical: sz.paddingV }]}
        >
          {loading
            ? <ActivityIndicator color={Colors.void} size="small" />
            : <Text style={[styles.btnTextPrimary, { fontSize: sz.fontSize, letterSpacing: sz.letterSpacing }]}>{label}</Text>
          }
        </LinearGradient>
      </Pressable>
    );
  }

  const variantStyle = {
    secondary: { border: Colors.border,  bg: Colors.leather, text: Colors.textMuted },
    ghost:     { border: 'transparent',  bg: 'transparent',  text: Colors.textMuted },
    danger:    { border: 'rgba(239,68,68,0.4)', bg: 'rgba(239,68,68,0.08)', text: Colors.error },
  }[variant];

  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      style={({ pressed }) => [
        styles.btnBase,
        {
          borderWidth: 1,
          borderColor: variantStyle.border,
          backgroundColor: variantStyle.bg,
          paddingVertical: sz.paddingV,
        },
        fullWidth && styles.fullWidth,
        isDisabled && styles.disabled,
        pressed && styles.pressed,
        style as ViewStyle,
      ]}
      {...rest}
    >
      {loading
        ? <ActivityIndicator color={Colors.gold} size="small" />
        : <Text style={[styles.btnTextSecondary, { fontSize: sz.fontSize, letterSpacing: sz.letterSpacing, color: variantStyle.text }]}>{label}</Text>
      }
    </Pressable>
  );
}

// ── CARD ──────────────────────────────────────────────────────────

interface CardProps {
  children: React.ReactNode;
  style?: ViewStyle;
  glow?: boolean;
  onPress?: () => void;
}

export function Card({ children, style, glow, onPress }: CardProps) {
  const content = (
    <View style={[styles.card, glow && Shadow.gold, style]}>
      {children}
    </View>
  );
  if (onPress) {
    return <Pressable onPress={onPress}>{content}</Pressable>;
  }
  return content;
}

// ── BADGE ─────────────────────────────────────────────────────────

type BadgeVariant = 'gold' | 'purple' | 'green' | 'red' | 'default';

export function Badge({ label, variant = 'default' }: { label: string; variant?: BadgeVariant }) {
  const colors: Record<BadgeVariant, { bg: string; text: string; border: string }> = {
    gold:    { bg: 'rgba(196,154,42,0.15)', text: Colors.goldBright, border: 'rgba(196,154,42,0.4)' },
    purple:  { bg: 'rgba(167,139,250,0.15)', text: '#C4B5FD', border: 'rgba(167,139,250,0.4)' },
    green:   { bg: 'rgba(34,197,94,0.15)',   text: Colors.success,   border: 'rgba(34,197,94,0.4)' },
    red:     { bg: 'rgba(239,68,68,0.15)',   text: Colors.error,     border: 'rgba(239,68,68,0.4)' },
    default: { bg: Colors.leather,           text: Colors.textMuted, border: Colors.border },
  };
  const c = colors[variant];
  return (
    <View style={[styles.badge, { backgroundColor: c.bg, borderColor: c.border }]}>
      <Text style={[styles.badgeText, { color: c.text }]}>{label}</Text>
    </View>
  );
}

// ── INPUT ─────────────────────────────────────────────────────────

interface InputProps {
  label?: string;
  value: string;
  onChangeText: (v: string) => void;
  placeholder?: string;
  secureTextEntry?: boolean;
  multiline?: boolean;
  keyboardType?: any;
  autoCapitalize?: any;
  style?: ViewStyle;
}

export function Input({
  label, value, onChangeText, placeholder,
  secureTextEntry, multiline, keyboardType,
  autoCapitalize, style
}: InputProps) {
  return (
    <View style={[styles.inputWrap, style]}>
      {label && <Text style={styles.inputLabel}>{label}</Text>}
      <TextInput
        style={[styles.inputField, multiline && styles.inputMultiline]}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={Colors.textDim}
        secureTextEntry={secureTextEntry}
        multiline={multiline}
        keyboardType={keyboardType}
        autoCapitalize={autoCapitalize ?? 'none'}
      />
    </View>
  );
}

// ── SCREEN HEADER ─────────────────────────────────────────────────

export function ScreenHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <LinearGradient colors={['#160e04', Colors.void]} style={styles.screenHeader}>
      <Text style={styles.screenHeaderLogo}>TRISK</Text>
      <Text style={styles.screenHeaderSub}>{subtitle ?? title}</Text>
    </LinearGradient>
  );
}

// ── DIVIDER ───────────────────────────────────────────────────────

export function Divider({ style }: { style?: ViewStyle }) {
  return <View style={[styles.divider, style]} />;
}

// ── EMPTY STATE ───────────────────────────────────────────────────

export function EmptyState({
  icon, title, message, action
}: {
  icon?: string;
  title: string;
  message?: string;
  action?: { label: string; onPress: () => void };
}) {
  return (
    <View style={styles.emptyWrap}>
      {icon && <Text style={styles.emptyIcon}>{icon}</Text>}
      <Text style={styles.emptyTitle}>{title}</Text>
      {message && <Text style={styles.emptyMessage}>{message}</Text>}
      {action && (
        <Button label={action.label} onPress={action.onPress} size="sm" style={{ marginTop: Spacing.base }} />
      )}
    </View>
  );
}

// ── STYLES ────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  // Button
  btnBase: { borderRadius: Radius.md, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' },
  btnGrad: { width: '100%', alignItems: 'center', justifyContent: 'center', paddingHorizontal: Spacing['2xl'] },
  btnTextPrimary: { fontFamily: Typography.display, color: Colors.void, textTransform: 'uppercase' },
  btnTextSecondary: { fontFamily: Typography.display, textTransform: 'uppercase' },
  fullWidth: { width: '100%' },
  disabled: { opacity: 0.5 },
  pressed: { opacity: 0.8 },

  // Card
  card: {
    backgroundColor: Colors.leather,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.lg,
    padding: Spacing.base,
  },

  // Badge
  badge: { paddingHorizontal: Spacing.sm, paddingVertical: 3, borderRadius: Radius.full, borderWidth: 1 },
  badgeText: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 1.5, textTransform: 'uppercase' },

  // Input
  inputWrap: { gap: Spacing.xs },
  inputLabel: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 2, textTransform: 'uppercase', color: Colors.textMuted },
  inputField: {
    backgroundColor: Colors.leather,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.md,
    padding: Spacing.base,
    fontFamily: Typography.sans,
    fontSize: Typography.base,
    color: Colors.textPrimary,
  },
  inputMultiline: { height: 100, textAlignVertical: 'top' },

  // Screen Header
  screenHeader: { paddingTop: 56, paddingBottom: Spacing.base, paddingHorizontal: Spacing['2xl'], flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  screenHeaderLogo: { fontFamily: Typography.display, fontSize: Typography.lg, letterSpacing: 4, color: Colors.goldBright },
  screenHeaderSub: { fontFamily: Typography.sans, fontSize: Typography.xs, letterSpacing: 3, textTransform: 'uppercase', color: Colors.textMuted },

  // Divider
  divider: { height: 1, backgroundColor: Colors.border },

  // Empty state
  emptyWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing['3xl'] },
  emptyIcon: { fontSize: 48, color: Colors.textDim, marginBottom: Spacing.base },
  emptyTitle: { fontFamily: Typography.display, fontSize: Typography.xl, color: Colors.goldBright, letterSpacing: 2, marginBottom: Spacing.sm, textAlign: 'center' },
  emptyMessage: { fontFamily: Typography.serifItalic, fontSize: Typography.base, color: Colors.textMuted, textAlign: 'center', lineHeight: Typography.base * 1.6 },
});
