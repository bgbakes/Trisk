// lib/supabase.ts
// Supabase client — Trisk app

import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { createClient } from '@supabase/supabase-js';
import { Platform } from 'react-native';
import Constants from 'expo-constants';

// ── Env vars (set in .env / EAS secrets) ──────────────────────────
const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL ?? '';
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '';

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  console.warn('[Trisk] Supabase env vars not set. Copy .env.example → .env');
}

// ── Secure storage adapter (iOS/Android) vs AsyncStorage (web) ────
const ExpoSecureStoreAdapter = {
  getItem: (key: string) => {
    if (Platform.OS === 'web') return AsyncStorage.getItem(key);
    return SecureStore.getItemAsync(key);
  },
  setItem: (key: string, value: string) => {
    if (Platform.OS === 'web') return AsyncStorage.setItem(key, value);
    return SecureStore.setItemAsync(key, value);
  },
  removeItem: (key: string) => {
    if (Platform.OS === 'web') return AsyncStorage.removeItem(key);
    return SecureStore.deleteItemAsync(key);
  },
};

// ── Supabase client ────────────────────────────────────────────────
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: ExpoSecureStoreAdapter as any,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// ── Auth helpers ───────────────────────────────────────────────────

export const signUp = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error) throw error;
  return data;
};

export const signIn = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  if (error) throw error;
  return data;
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
};

export const getSession = async () => {
  const { data: { session }, error } = await supabase.auth.getSession();
  if (error) throw error;
  return session;
};

export const getUser = async () => {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error) throw error;
  return user;
};

// ── Profile helpers ────────────────────────────────────────────────

export const getProfile = async (userId: string) => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();
  if (error) throw error;
  return data;
};

export const updateProfile = async (userId: string, updates: Record<string, any>) => {
  const { data, error } = await supabase
    .from('profiles')
    .upsert({ id: userId, ...updates, updated_at: new Date().toISOString() });
  if (error) throw error;
  return data;
};

// ── Dynamic helpers ────────────────────────────────────────────────

export const getDynamic = async (dynamicId: string) => {
  const { data, error } = await supabase
    .from('dynamics')
    .select(`*, dominant:profiles!dominant_id(*), submissive:profiles!submissive_id(*)`)
    .eq('id', dynamicId)
    .single();
  if (error) throw error;
  return data;
};

export const getMyDynamics = async (userId: string) => {
  const { data, error } = await supabase
    .from('dynamics')
    .select('*')
    .or(`dominant_id.eq.${userId},submissive_id.eq.${userId}`)
    .eq('is_active', true)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data;
};

// ── Task helpers ───────────────────────────────────────────────────

export const getMyTasks = async (userId: string) => {
  const { data, error } = await supabase
    .from('tasks')
    .select('*')
    .eq('assigned_to', userId)
    .order('due_at', { ascending: true });
  if (error) throw error;
  return data;
};

export const completeTask = async (taskId: string, note?: string, proofUrl?: string) => {
  const { data, error } = await supabase
    .from('tasks')
    .update({
      status: 'completed',
      completed_at: new Date().toISOString(),
      completion_note: note,
      proof_url: proofUrl,
    })
    .eq('id', taskId);
  if (error) throw error;
  return data;
};

// ── Connect / Matching ─────────────────────────────────────────────

export const getDiscoverProfiles = async (userId: string, filters?: Record<string, any>) => {
  let query = supabase
    .from('profiles')
    .select('*')
    .neq('id', userId)
    .eq('discreet_mode', false);

  if (filters?.role) query = query.contains('looking_for', [filters.role]);

  const { data, error } = await query.limit(20);
  if (error) throw error;
  return data;
};

export const sendLike = async (fromId: string, toId: string) => {
  const { data, error } = await supabase
    .from('matches')
    .upsert({
      profile_a_id: fromId,
      profile_b_id: toId,
      status: 'pending',
      initiated_by: fromId,
    });
  if (error) throw error;
  return data;
};

// ── Real-time subscriptions ────────────────────────────────────────

export const subscribeToMessages = (
  matchId: string,
  callback: (payload: any) => void
) => {
  return supabase
    .channel(`messages:${matchId}`)
    .on('postgres_changes', {
      event: 'INSERT',
      schema: 'public',
      table: 'messages',
      filter: `match_id=eq.${matchId}`,
    }, callback)
    .subscribe();
};

export const subscribeToTasks = (
  dynamicId: string,
  callback: (payload: any) => void
) => {
  return supabase
    .channel(`tasks:${dynamicId}`)
    .on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'tasks',
      filter: `dynamic_id=eq.${dynamicId}`,
    }, callback)
    .subscribe();
};
