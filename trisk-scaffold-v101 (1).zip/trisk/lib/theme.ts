// lib/theme.ts
// Trisk Design System — Black + Gold luxury brand

export const Colors = {
  // Core
  void:        '#080806',
  leather:     '#160e04',
  darkLeather: '#0E0A02',

  // Gold scale
  goldDeep:    '#6B4F18',
  gold:        '#C49A2A',
  goldBright:  '#E8C244',
  goldPale:    '#F7E88A',

  // Text
  cream:       '#F2EBD9',
  textPrimary: '#F2EBD9',
  textMuted:   '#6A5E42',
  textDim:     '#3D3424',

  // Status
  success:     '#22C55E',
  warning:     '#F59E0B',
  error:       '#EF4444',
  info:        '#3B82F6',

  // Dynamic role colors
  dominant:    '#E8C244',  // gold
  submissive:  '#A78BFA',  // soft purple
  switch:      '#6EE7B7',  // mint

  // UI
  border:      'rgba(196,154,42,0.18)',
  borderBright:'rgba(196,154,42,0.4)',
  surface:     'rgba(255,248,220,0.03)',
  surfaceHover:'rgba(255,248,220,0.06)',
  overlay:     'rgba(8,8,6,0.85)',

  // Tab bar
  tabActive:   '#E8C244',
  tabInactive: '#3D3424',
};

export const Typography = {
  // Font families — to be loaded via expo-font
  display:   'Cinzel_700Bold',
  serif:     'CormorantGaramond_400Regular',
  serifItalic: 'CormorantGaramond_400Italic',
  sans:      'Outfit_300Light',
  sansMed:   'Outfit_400Regular',

  // Sizes
  xs:   10,
  sm:   12,
  base: 14,
  md:   16,
  lg:   18,
  xl:   22,
  '2xl': 28,
  '3xl': 36,
  '4xl': 48,

  // Line heights
  tight:  1.1,
  normal: 1.5,
  loose:  1.75,

  // Letter spacing
  tight_ls:  -0.5,
  normal_ls: 0,
  wide_ls:   1,
  wider_ls:  2,
  widest_ls: 4,
};

export const Spacing = {
  xs:   4,
  sm:   8,
  md:   12,
  base: 16,
  lg:   20,
  xl:   24,
  '2xl': 32,
  '3xl': 40,
  '4xl': 48,
  '5xl': 64,
};

export const Radius = {
  sm:   6,
  md:   10,
  lg:   14,
  xl:   20,
  full: 999,
};

export const Shadow = {
  gold: {
    shadowColor: '#C49A2A',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 8,
  },
  goldGlow: {
    shadowColor: '#E8C244',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.4,
    shadowRadius: 20,
    elevation: 12,
  },
  dark: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.6,
    shadowRadius: 16,
    elevation: 10,
  },
};

// Gradient presets
export const Gradients = {
  gold: ['#F7E88A', '#E8C244', '#C49A2A', '#7A5010'] as const,
  goldShort: ['#E8C244', '#C49A2A'] as const,
  darkBg: ['#160e04', '#080806'] as const,
  leather: ['#1C1208', '#0E0A02'] as const,
  dominant: ['#F7E88A', '#C49A2A'] as const,
  submissive: ['#C4B5FD', '#7C3AED'] as const,
};
