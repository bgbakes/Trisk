// lib/types.ts
// Trisk — Core TypeScript type definitions

// ── ENUMS ──────────────────────────────────────────────────────────

export type DynamicRole = 'dominant' | 'submissive' | 'switch';

export type DynamicType =
  | 'D/s'        // Dominant/submissive
  | 'M/s'        // Master/slave
  | 'O/p'        // Owner/property
  | 'DD/lg'      // Daddy Dom/little girl
  | 'MD/lb'      // Mommy Dom/little boy
  | 'CG/l'       // Caregiver/little
  | 'pet_play'   // Owner/pet
  | 'TPE'        // Total Power Exchange
  | 'other';

export type TaskStatus = 'pending' | 'completed' | 'failed' | 'excused';
export type TaskFrequency = 'once' | 'daily' | 'weekly' | 'monthly';
export type MatchStatus = 'pending' | 'accepted' | 'declined' | 'blocked';
export type PostType = 'text' | 'image' | 'event' | 'question';

// ── USER / PROFILE ─────────────────────────────────────────────────

export interface Profile {
  id: string;
  username: string;
  display_name: string;
  avatar_url?: string;
  bio?: string;
  role: DynamicRole;
  dynamic_types: DynamicType[];
  age?: number;
  location?: string;           // city only, never exact
  experience_years?: number;
  is_collared: boolean;
  collar_visible: boolean;     // show collar status publicly
  looking_for: DynamicRole[];
  kinks: string[];             // from standardized list
  hard_limits: string[];       // private, shown to matches only
  is_verified: boolean;
  is_premium: boolean;         // Pro tier
  is_elite: boolean;           // Collar tier
  discreet_mode: boolean;      // hide from non-members
  created_at: string;
  updated_at: string;
}

// ── DYNAMIC (D/s Relationship) ──────────────────────────────────────

export interface Dynamic {
  id: string;
  dominant_id: string;
  submissive_id?: string;      // null for solo practice
  title: string;               // e.g. "Our Dynamic"
  dynamic_type: DynamicType;
  dom_title: string;           // e.g. "Sir", "Daddy", "Master"
  sub_title: string;           // e.g. "babygirl", "pet", "slave"
  started_at: string;
  collar_date?: string;
  is_active: boolean;
  contract_url?: string;
  safeword: string;
  safeword_signal?: string;    // non-verbal signal
  rules_count: number;
  tasks_count: number;
  streak_days: number;
  created_at: string;
}

// ── TASKS ───────────────────────────────────────────────────────────

export interface Task {
  id: string;
  dynamic_id: string;
  assigned_by: string;         // profile id
  assigned_to: string;         // profile id
  title: string;
  description?: string;
  frequency: TaskFrequency;
  due_at?: string;
  status: TaskStatus;
  points_value: number;
  completed_at?: string;
  completion_note?: string;
  proof_required: boolean;
  proof_url?: string;
  created_at: string;
}

// ── RULES ───────────────────────────────────────────────────────────

export interface Rule {
  id: string;
  dynamic_id: string;
  title: string;
  description?: string;
  category: 'behavior' | 'protocol' | 'physical' | 'communication' | 'other';
  is_active: boolean;
  consequence?: string;
  created_at: string;
}

// ── RITUALS ─────────────────────────────────────────────────────────

export interface Ritual {
  id: string;
  dynamic_id: string;
  title: string;
  description?: string;
  time_of_day: 'morning' | 'afternoon' | 'evening' | 'bedtime' | 'anytime';
  frequency: TaskFrequency;
  last_completed_at?: string;
  streak: number;
  is_active: boolean;
}

// ── JOURNAL ─────────────────────────────────────────────────────────

export interface JournalEntry {
  id: string;
  author_id: string;
  dynamic_id?: string;
  title?: string;
  content: string;
  mood_score?: number;         // 1-10
  sub_depth_score?: number;    // 1-10 (submissive headspace depth)
  tags: string[];
  is_private: boolean;
  shared_with?: string;        // partner profile id
  media_urls: string[];
  created_at: string;
}

// ── CHECK-IN ────────────────────────────────────────────────────────

export interface CheckIn {
  id: string;
  profile_id: string;
  dynamic_id?: string;
  mood: number;                // 1-10
  energy: number;              // 1-10
  submission_depth?: number;   // 1-10 (for subs)
  dominance_level?: number;    // 1-10 (for doms)
  note?: string;
  created_at: string;
}

// ── REWARDS / PUNISHMENTS ───────────────────────────────────────────

export interface RewardEntry {
  id: string;
  dynamic_id: string;
  profile_id: string;          // recipient
  type: 'reward' | 'punishment' | 'forgiveness';
  title: string;
  description?: string;
  points_delta: number;        // positive = reward, negative = punishment
  created_at: string;
}

// ── CONNECT (Dating) ────────────────────────────────────────────────

export interface Match {
  id: string;
  profile_a_id: string;
  profile_b_id: string;
  status: MatchStatus;
  initiated_by: string;
  matched_at?: string;
  last_message_at?: string;
  created_at: string;
}

export interface Message {
  id: string;
  match_id: string;
  sender_id: string;
  content: string;
  media_url?: string;
  is_read: boolean;
  created_at: string;
}

// ── COMMUNITY ───────────────────────────────────────────────────────

export interface Post {
  id: string;
  author_id: string;
  type: PostType;
  title?: string;
  content: string;
  media_urls: string[];
  tags: string[];
  upvotes: number;
  comment_count: number;
  is_nsfw: boolean;
  is_pinned: boolean;
  created_at: string;
}

export interface Comment {
  id: string;
  post_id: string;
  author_id: string;
  content: string;
  upvotes: number;
  created_at: string;
}

// ── NAVIGATION TYPES ────────────────────────────────────────────────

export type RootStackParamList = {
  '(auth)': undefined;
  '(tabs)': undefined;
};

export type AuthStackParamList = {
  welcome: undefined;
  login: undefined;
  signup: undefined;
  onboarding: {step?: number};
};

export type TabParamList = {
  connect: undefined;
  track: undefined;
  scene: undefined;
  profile: undefined;
};
