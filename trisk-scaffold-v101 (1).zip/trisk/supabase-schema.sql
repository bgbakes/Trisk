-- ═══════════════════════════════════════════════════
-- TRISK · Supabase Database Schema
-- Run this in your Supabase SQL Editor
-- ═══════════════════════════════════════════════════

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ── PROFILES ──────────────────────────────────────────────────────
create table profiles (
  id                uuid references auth.users on delete cascade primary key,
  username          text unique not null,
  display_name      text,
  avatar_url        text,
  bio               text,
  role              text not null check (role in ('dominant','submissive','switch')),
  dynamic_types     text[] default '{}',
  age               int,
  location          text,
  experience_years  int default 0,
  is_collared       boolean default false,
  collar_visible    boolean default true,
  looking_for       text[] default '{}',
  kinks             text[] default '{}',
  hard_limits       text[] default '{}',
  is_verified       boolean default false,
  is_premium        boolean default false,
  is_elite          boolean default false,
  discreet_mode     boolean default false,
  created_at        timestamptz default now(),
  updated_at        timestamptz default now()
);

-- Row Level Security
alter table profiles enable row level security;
create policy "Public profiles are viewable" on profiles for select using (not discreet_mode or auth.uid() = id);
create policy "Users can update own profile" on profiles for update using (auth.uid() = id);
create policy "Users can insert own profile" on profiles for insert with check (auth.uid() = id);

-- Auto-create profile on signup
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, username)
  values (new.id, 'user_' || substr(new.id::text, 1, 8));
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();

-- ── DYNAMICS ──────────────────────────────────────────────────────
create table dynamics (
  id              uuid default uuid_generate_v4() primary key,
  dominant_id     uuid references profiles(id) on delete cascade not null,
  submissive_id   uuid references profiles(id) on delete set null,
  title           text not null default 'Our Dynamic',
  dynamic_type    text not null check (dynamic_type in ('D/s','M/s','O/p','DD/lg','MD/lb','CG/l','pet_play','TPE','other')),
  dom_title       text not null default 'Sir',
  sub_title       text not null default 'pet',
  started_at      timestamptz default now(),
  collar_date     timestamptz,
  is_active       boolean default true,
  contract_url    text,
  safeword        text not null default 'safeword',
  safeword_signal text,
  rules_count     int default 0,
  tasks_count     int default 0,
  streak_days     int default 0,
  created_at      timestamptz default now()
);

alter table dynamics enable row level security;
create policy "Dynamic members can view" on dynamics for select
  using (auth.uid() = dominant_id or auth.uid() = submissive_id);
create policy "Dominant can manage dynamic" on dynamics for all
  using (auth.uid() = dominant_id);

-- ── TASKS ─────────────────────────────────────────────────────────
create table tasks (
  id               uuid default uuid_generate_v4() primary key,
  dynamic_id       uuid references dynamics(id) on delete cascade,
  assigned_by      uuid references profiles(id),
  assigned_to      uuid references profiles(id),
  title            text not null,
  description      text,
  frequency        text default 'once' check (frequency in ('once','daily','weekly','monthly')),
  due_at           timestamptz,
  status           text default 'pending' check (status in ('pending','completed','failed','excused')),
  points_value     int default 5,
  completed_at     timestamptz,
  completion_note  text,
  proof_required   boolean default false,
  proof_url        text,
  created_at       timestamptz default now()
);

alter table tasks enable row level security;
create policy "Dynamic members can view tasks" on tasks for select
  using (auth.uid() in (select dominant_id from dynamics where id = dynamic_id)
    or auth.uid() in (select submissive_id from dynamics where id = dynamic_id));
create policy "Assigned user can complete task" on tasks for update
  using (auth.uid() = assigned_to);
create policy "Dominant can manage tasks" on tasks for all
  using (auth.uid() = assigned_by);

-- ── RULES ─────────────────────────────────────────────────────────
create table rules (
  id          uuid default uuid_generate_v4() primary key,
  dynamic_id  uuid references dynamics(id) on delete cascade,
  title       text not null,
  description text,
  category    text default 'behavior' check (category in ('behavior','protocol','physical','communication','other')),
  is_active   boolean default true,
  consequence text,
  created_at  timestamptz default now()
);

alter table rules enable row level security;
create policy "Dynamic members can view rules" on rules for select
  using (auth.uid() in (select dominant_id from dynamics where id = dynamic_id)
    or auth.uid() in (select submissive_id from dynamics where id = dynamic_id));
create policy "Dominant manages rules" on rules for all
  using (auth.uid() in (select dominant_id from dynamics where id = dynamic_id));

-- ── RITUALS ───────────────────────────────────────────────────────
create table rituals (
  id                uuid default uuid_generate_v4() primary key,
  dynamic_id        uuid references dynamics(id) on delete cascade,
  title             text not null,
  description       text,
  time_of_day       text check (time_of_day in ('morning','afternoon','evening','bedtime','anytime')),
  frequency         text default 'daily',
  last_completed_at timestamptz,
  streak            int default 0,
  is_active         boolean default true
);

-- ── JOURNAL ───────────────────────────────────────────────────────
create table journal_entries (
  id               uuid default uuid_generate_v4() primary key,
  author_id        uuid references profiles(id) on delete cascade,
  dynamic_id       uuid references dynamics(id) on delete set null,
  title            text,
  content          text not null,
  mood_score       int check (mood_score between 1 and 10),
  sub_depth_score  int check (sub_depth_score between 1 and 10),
  tags             text[] default '{}',
  is_private       boolean default true,
  shared_with      uuid references profiles(id),
  media_urls       text[] default '{}',
  created_at       timestamptz default now()
);

alter table journal_entries enable row level security;
create policy "Author views own entries" on journal_entries for select
  using (auth.uid() = author_id or (not is_private and auth.uid() = shared_with));
create policy "Author manages entries" on journal_entries for all
  using (auth.uid() = author_id);

-- ── CHECK-INS ─────────────────────────────────────────────────────
create table check_ins (
  id                uuid default uuid_generate_v4() primary key,
  profile_id        uuid references profiles(id) on delete cascade,
  dynamic_id        uuid references dynamics(id) on delete set null,
  mood              int not null check (mood between 1 and 10),
  energy            int not null check (energy between 1 and 10),
  submission_depth  int check (submission_depth between 1 and 10),
  dominance_level   int check (dominance_level between 1 and 10),
  note              text,
  created_at        timestamptz default now()
);

-- ── MATCHES ───────────────────────────────────────────────────────
create table matches (
  id              uuid default uuid_generate_v4() primary key,
  profile_a_id    uuid references profiles(id),
  profile_b_id    uuid references profiles(id),
  status          text default 'pending' check (status in ('pending','accepted','declined','blocked')),
  initiated_by    uuid references profiles(id),
  matched_at      timestamptz,
  last_message_at timestamptz,
  created_at      timestamptz default now(),
  unique(profile_a_id, profile_b_id)
);

alter table matches enable row level security;
create policy "Match participants can view" on matches for select
  using (auth.uid() = profile_a_id or auth.uid() = profile_b_id);

-- ── MESSAGES ──────────────────────────────────────────────────────
create table messages (
  id         uuid default uuid_generate_v4() primary key,
  match_id   uuid references matches(id) on delete cascade,
  sender_id  uuid references profiles(id),
  content    text not null,
  media_url  text,
  is_read    boolean default false,
  created_at timestamptz default now()
);

alter table messages enable row level security;
create policy "Match participants can view messages" on messages for select
  using (auth.uid() in (select profile_a_id from matches where id = match_id)
    or auth.uid() in (select profile_b_id from matches where id = match_id));
create policy "Sender can insert messages" on messages for insert
  with check (auth.uid() = sender_id);

-- ── COMMUNITY POSTS ───────────────────────────────────────────────
create table posts (
  id            uuid default uuid_generate_v4() primary key,
  author_id     uuid references profiles(id) on delete cascade,
  type          text default 'text' check (type in ('text','image','event','question')),
  title         text,
  content       text not null,
  media_urls    text[] default '{}',
  tags          text[] default '{}',
  upvotes       int default 0,
  comment_count int default 0,
  is_nsfw       boolean default false,
  is_pinned     boolean default false,
  created_at    timestamptz default now()
);

alter table posts enable row level security;
create policy "Anyone can view posts" on posts for select using (true);
create policy "Author manages posts" on posts for all using (auth.uid() = author_id);

-- ── REALTIME ──────────────────────────────────────────────────────
-- Enable realtime for messages and tasks
alter publication supabase_realtime add table messages;
alter publication supabase_realtime add table tasks;
alter publication supabase_realtime add table check_ins;

-- ── INDEXES ───────────────────────────────────────────────────────
create index profiles_role_idx on profiles(role);
create index tasks_assigned_to_idx on tasks(assigned_to, status);
create index tasks_dynamic_id_idx on tasks(dynamic_id);
create index messages_match_id_idx on messages(match_id, created_at desc);
create index posts_created_at_idx on posts(created_at desc);
create index matches_profiles_idx on matches(profile_a_id, profile_b_id);
