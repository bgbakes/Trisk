'use client';
// app/(app)/scene/page.tsx
import { useState } from 'react';

const MOCK_POSTS = [
  {
    id: '1', author: 'Sir_Marcus', role: 'dominant', time: '2h',
    content: 'Reminder: aftercare isn\'t optional. It\'s the most important part of any scene. Non-negotiable.',
    upvotes: 47, comments: 12, tags: ['aftercare', 'protocol'],
  },
  {
    id: '2', author: 'petKira', role: 'submissive', time: '5h',
    content: 'Anyone in the Las Vegas D/s community? Looking for local munches 🖤',
    upvotes: 23, comments: 18, tags: ['LasVegas', 'munch', 'D/s'],
  },
  {
    id: '3', author: 'LVLeatherSociety', role: 'community', time: '1d',
    content: '📍 Monthly Las Vegas Munch — Saturday 7pm. DM for location. All dynamics welcome.',
    upvotes: 89, comments: 34, tags: ['munch', 'LasVegas', 'event'],
  },
];

const ROLE_COLOR: Record<string, string> = {
  dominant:  '#E8C244',
  submissive:'#C4B5FD',
  switch:    '#6EE7B7',
  community: '#60A5FA',
};

export default function ScenePage() {
  const [posts, setPosts] = useState(MOCK_POSTS);

  return (
    <div className="flex flex-col">

      {/* Composer */}
      <div className="mx-4 mt-4 mb-3 card flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-leather-dark border border-gold-deep/25 flex-shrink-0" />
        <span className="flex-1 font-sans text-sm text-dim">Share with the scene...</span>
        <button className="font-sans text-[10px] tracking-widest text-gold-bright border border-gold-deep/35 rounded-full px-3 py-1">
          Post
        </button>
      </div>

      {/* Feed */}
      <div className="flex flex-col gap-3 px-4 pb-4">
        {posts.map(p => (
          <div key={p.id} className="card">
            {/* Header */}
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-full bg-leather-dark border border-gold-deep/25 flex items-center justify-center flex-shrink-0">
                <span className="font-display text-sm text-gold-bright">{p.author[0]}</span>
              </div>
              <div>
                <p className="font-display text-sm tracking-wider text-cream">{p.author}</p>
                <p className="font-sans text-[9px] tracking-widest" style={{ color: ROLE_COLOR[p.role] }}>
                  {p.role} · {p.time}
                </p>
              </div>
            </div>

            {/* Content */}
            <p className="font-serif text-base text-cream leading-relaxed mb-3">{p.content}</p>

            {/* Tags */}
            <div className="flex gap-2 flex-wrap mb-3">
              {p.tags.map(t => (
                <span key={t} className="font-sans text-[9px] text-gold-deep tracking-widest">#{t}</span>
              ))}
            </div>

            {/* Actions */}
            <div className="divider mb-3" />
            <div className="flex gap-6">
              <button onClick={() => setPosts(prev => prev.map(pp => pp.id === p.id ? { ...pp, upvotes: pp.upvotes + 1 } : pp))}
                className="font-sans text-[10px] text-muted hover:text-gold-bright transition-colors tracking-widest">
                ♥ {p.upvotes}
              </button>
              <button className="font-sans text-[10px] text-muted hover:text-gold-bright transition-colors tracking-widest">
                ◎ {p.comments}
              </button>
              <button className="font-sans text-[10px] text-muted hover:text-gold-bright transition-colors tracking-widest">
                ↗ Share
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}
