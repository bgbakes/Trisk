'use client';
// app/(app)/track/page.tsx
import { useState } from 'react';

type Tab = 'overview' | 'tasks' | 'rules' | 'journal';

const MOCK_DYNAMIC = {
  dom_title: 'Sir', sub_title: 'babygirl',
  type: 'D/s', streak: 14, points: 287,
};

const MOCK_TASKS = [
  { id: '1', title: 'Morning gratitude text',   status: 'pending',   pts: 5,  due: 'Today 9am'  },
  { id: '2', title: 'Evening check-in',          status: 'pending',   pts: 5,  due: 'Today 9pm'  },
  { id: '3', title: 'Wear collar all day',       status: 'completed', pts: 10, due: 'Today'       },
  { id: '4', title: 'Journal entry',             status: 'pending',   pts: 8,  due: 'Tonight'     },
];

const MOCK_RULES = [
  { id: '1', title: 'Address Sir by title at all times',       active: true,  cat: 'protocol'  },
  { id: '2', title: 'Ask permission before spending over $50', active: true,  cat: 'behavior'  },
  { id: '3', title: 'No social media after 10pm',              active: true,  cat: 'behavior'  },
  { id: '4', title: 'Daily stretching routine',                active: false, cat: 'physical'  },
];

export default function TrackPage() {
  const [tab, setTab]     = useState<Tab>('overview');
  const [tasks, setTasks] = useState(MOCK_TASKS);
  const [mood, setMood]   = useState(7);

  const done  = tasks.filter(t => t.status === 'completed').length;
  const total = tasks.length;
  const pct   = Math.round((done / total) * 100);

  const toggle = (id: string) =>
    setTasks(prev => prev.map(t =>
      t.id === id ? { ...t, status: t.status === 'completed' ? 'pending' : 'completed' } : t
    ));

  const TABS: { key: Tab; label: string }[] = [
    { key: 'overview', label: 'Overview' },
    { key: 'tasks',    label: 'Tasks'    },
    { key: 'rules',    label: 'Rules'    },
    { key: 'journal',  label: 'Journal'  },
  ];

  return (
    <div className="flex flex-col">

      {/* Sub-nav */}
      <div className="flex border-b border-gold-deep/20 bg-leather-dark sticky top-0 z-10">
        {TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`flex-1 py-3 font-sans text-[9px] tracking-[0.15em] uppercase border-b-2 transition-colors ${
              tab === t.key ? 'text-gold-bright border-gold-bright' : 'text-muted border-transparent hover:text-cream'
            }`}>
            {t.label}
          </button>
        ))}
      </div>

      <div className="px-4 py-4 space-y-4">

        {/* ── OVERVIEW ── */}
        {tab === 'overview' && (
          <>
            {/* Dynamic banner */}
            <div className="card" style={{ background: 'linear-gradient(135deg, rgba(196,154,42,0.12), rgba(196,154,42,0.03))' }}>
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-sans text-[9px] tracking-[0.3em] uppercase text-muted mb-1">Your Dynamic</p>
                  <p className="font-display text-xl tracking-widest text-gold-bright">
                    {MOCK_DYNAMIC.dom_title} / {MOCK_DYNAMIC.sub_title}
                  </p>
                  <p className="font-sans text-[10px] text-muted mt-0.5 tracking-widest">{MOCK_DYNAMIC.type}</p>
                </div>
                <div className="text-center border border-gold-deep/30 rounded-xl p-3">
                  <p className="font-display text-2xl text-gold-bright">{MOCK_DYNAMIC.streak}</p>
                  <p className="font-sans text-[9px] text-muted tracking-widest">day streak</p>
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-2">
              {[
                { v: MOCK_DYNAMIC.points, l: 'Points' },
                { v: `${done}/${total}`,  l: 'Today'  },
                { v: MOCK_DYNAMIC.streak, l: 'Streak' },
              ].map(s => (
                <div key={s.l} className="card text-center py-3">
                  <p className="font-display text-xl text-gold-bright">{s.v}</p>
                  <p className="font-sans text-[9px] text-muted tracking-widest uppercase">{s.l}</p>
                </div>
              ))}
            </div>

            {/* Progress */}
            <div>
              <div className="h-1 bg-leather rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${pct}%`, background: 'linear-gradient(90deg, #E8C244, #C49A2A)' }} />
              </div>
              <p className="font-sans text-[10px] text-muted mt-1.5">{done} of {total} protocols completed today</p>
            </div>

            {/* Today's tasks preview */}
            <div>
              <p className="font-display text-[10px] tracking-[0.25em] uppercase text-gold-bright mb-3">
                Today's Protocols
              </p>
              {tasks.slice(0, 3).map(t => (
                <TaskRow key={t.id} task={t} onToggle={toggle} />
              ))}
            </div>

            {/* Mood check-in */}
            <div className="card">
              <p className="font-sans text-[10px] tracking-[0.25em] uppercase text-muted mb-3">Daily Check-in</p>
              <p className="font-sans text-xs text-muted mb-2">Mood today</p>
              <div className="flex gap-1.5 flex-wrap mb-2">
                {Array.from({ length: 10 }, (_, i) => i + 1).map(n => (
                  <button key={n} onClick={() => setMood(n)}
                    className={`w-6 h-6 rounded-full transition-all ${
                      mood >= n
                        ? 'bg-gold-bright'
                        : 'bg-leather-dark border border-gold-deep/25'
                    }`} />
                ))}
              </div>
              <p className="font-display text-lg text-gold-bright">{mood}/10</p>
            </div>
          </>
        )}

        {/* ── TASKS ── */}
        {tab === 'tasks' && (
          <>
            <div className="flex justify-between items-center">
              <p className="font-display text-[10px] tracking-[0.25em] uppercase text-gold-bright">All Tasks</p>
              <button className="btn-outline text-[9px] py-1.5 px-3">+ Add Task</button>
            </div>
            {tasks.map(t => <TaskRow key={t.id} task={t} onToggle={toggle} />)}
          </>
        )}

        {/* ── RULES ── */}
        {tab === 'rules' && (
          <>
            <div className="flex justify-between items-center">
              <p className="font-display text-[10px] tracking-[0.25em] uppercase text-gold-bright">Protocols & Rules</p>
              <button className="btn-outline text-[9px] py-1.5 px-3">+ Add Rule</button>
            </div>
            {MOCK_RULES.map(r => (
              <div key={r.id} className="card flex items-center gap-4">
                <div className={`w-2 h-2 rounded-full flex-shrink-0 ${r.active ? 'bg-green-400' : 'bg-dim'}`} />
                <div className="flex-1">
                  <p className={`font-sans text-sm text-cream ${!r.active && 'opacity-40'}`}>{r.title}</p>
                  <p className="font-sans text-[9px] uppercase tracking-widest text-muted mt-0.5">{r.cat}</p>
                </div>
              </div>
            ))}
          </>
        )}

        {/* ── JOURNAL ── */}
        {tab === 'journal' && (
          <div className="flex flex-col items-center justify-center py-16 gap-4">
            <p className="text-4xl opacity-20">◉</p>
            <p className="font-display text-xl tracking-widest text-gold-bright">Your Journal</p>
            <p className="font-serif italic text-muted text-center text-sm leading-relaxed">
              Record your dynamic experiences,<br/>reflections, and growth.
            </p>
            <button className="btn-gold mt-4">Write First Entry</button>
          </div>
        )}

      </div>
    </div>
  );
}

function TaskRow({ task, onToggle }: { task: any; onToggle: (id: string) => void }) {
  const done = task.status === 'completed';
  return (
    <div className="flex items-center gap-3 py-3 border-b border-gold-deep/10 last:border-0 cursor-pointer"
      onClick={() => onToggle(task.id)}>
      <div className={`w-5 h-5 rounded-full border flex-shrink-0 flex items-center justify-center transition-all ${
        done ? 'bg-gold-bright border-gold-bright' : 'border-gold-deep/40'
      }`}>
        {done && <span className="text-void text-[10px] font-bold">✓</span>}
      </div>
      <div className="flex-1">
        <p className={`font-sans text-sm text-cream ${done && 'line-through opacity-40'}`}>{task.title}</p>
        <p className="font-sans text-[10px] text-muted">{task.due}</p>
      </div>
      <p className="font-sans text-[10px] text-gold-deep">+{task.pts}pts</p>
    </div>
  );
}
