'use client';
// app/login/page.tsx
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
import TriskelionSVG from '@/components/ui/TriskelionSVG';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); setLoading(true);
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) { setError(error.message); setLoading(false); return; }
    router.push('/track');
    router.refresh();
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6 py-16"
      style={{ background: 'radial-gradient(ellipse 60% 50% at 50% 40%, #1a0d02 0%, #080806 70%)' }}>

      <Link href="/" className="mb-10">
        <TriskelionSVG size={72} />
      </Link>

      <h1 className="font-display text-3xl font-black tracking-[0.2em] gold-text mb-2">
        Welcome Back
      </h1>
      <p className="font-serif italic text-muted mb-10">Your dynamic is waiting.</p>

      <form onSubmit={handleLogin} className="w-full max-w-sm flex flex-col gap-4">
        <div>
          <label className="label">Email</label>
          <input className="input" type="email" value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="your@email.com" required autoComplete="email" />
        </div>
        <div>
          <label className="label">Password</label>
          <input className="input" type="password" value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="••••••••" required autoComplete="current-password" />
        </div>

        {error && (
          <p className="text-xs text-red-400 font-sans tracking-wide">{error}</p>
        )}

        <div className="flex justify-end">
          <Link href="/reset-password" className="font-sans text-[10px] text-gold-deep hover:text-gold tracking-widest">
            Forgot password?
          </Link>
        </div>

        <button type="submit" disabled={loading}
          className="btn-gold mt-2 disabled:opacity-50">
          {loading ? 'Signing in...' : 'Enter'}
        </button>
      </form>

      <p className="font-sans text-xs text-muted mt-8">
        New to Trisk?{' '}
        <Link href="/signup" className="text-gold-bright hover:underline">Join the scene</Link>
      </p>
    </main>
  );
}
